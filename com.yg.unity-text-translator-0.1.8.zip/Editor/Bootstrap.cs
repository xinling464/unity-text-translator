using System;
using UnityEditor;
using UnityEngine;

namespace YGTextTranslator
{
    /// <summary>
    /// 插件加载即挂上显示层拦截 —— 之前只有自检代码会调 HookHost.Enable()，
    /// 正常进编辑器时没人调，于是所有 Prefix 都在 `if (!Enabled) return text;` 处原样放行，
    /// 表现为「装了但一个字都没翻」。这里补上真正的启动入口。
    /// </summary>
    [InitializeOnLoad]
    internal static class Bootstrap
    {
        static Bootstrap()
        {
            EditorApplication.delayCall += () => TryEnable(false);
        }

        [MenuItem("Tools/团子冲击！/立即启用翻译", false, 20)]
        private static void EnableFromMenu()
        {
            TryEnable(true);
        }

        internal static void TryEnable(bool verbose)
        {
            try
            {
                if (HookHost.Enabled)
                {
                    if (verbose) Debug.Log($"[YG] 拦截已在运行（{HookHost.PatchedCount} 个入口）");
                    return;
                }

                HookHost.Enable();
                UiTextHook.TryInit();
                EditorApplication.delayCall += () => { try { UiTextHook.Sweep(); } catch { } }; // UI Toolkit 面板（MA / NDMF / VRChat SDK）另走一条链路
                string src;
                try { src = HarmonyLoader.Source ?? "?"; } catch { src = "?"; }
                Debug.Log($"[YG] 显示层拦截已启用：patched={HookHost.PatchedCount}，harmony={src}");
            }
            catch (Exception e)
            {
                Debug.LogError("[YG] 启用显示层拦截失败：" + e);
            }
        }
    }
}
