﻿using UnityEditor;
using UnityEngine;

namespace YGTextTranslator
{
    /// <summary>
    /// 探针窗口：显示 PatchedCount / 命中次数 / 最近 10 条被截获的文本，并控制 HookHost 的启停。
    /// 自身绘制期间会抑制捕获，避免列表自我增殖。
    /// </summary>
    public class TranslatorWindow : EditorWindow
    {
        static bool _autoEnableAttempted;

        [MenuItem("Tools/团子冲击！/插件文本翻译")]
        static void Open() => GetWindow<TranslatorWindow>("插件文本翻译");

        void OnGUI()
        {
            // 窗口自己的 OnGUI 文字不应该进入截获列表（Inspector 的 OnGUI 是独立调用，不受影响）。
            // 窗口自己的 OnGUI 文字不进入截获列表，也不被替换成中文。
            var previousCapture = HookHost.SuppressCapture;
            var previousSuppress = TextPipeline.Suppress;
            HookHost.SuppressCapture = true;
            TextPipeline.Suppress = true;
            try
            {
                EnsureProbe();
                Draw();
            }
            finally
            {
                TextPipeline.Suppress = previousSuppress;
                HookHost.SuppressCapture = previousCapture;
            }
        }

        static void EnsureProbe()
        {
            if (_autoEnableAttempted) return;
            _autoEnableAttempted = true;
            HookHost.ProbeMode = true;
            HookHost.Enable();
        }

        static string PackageVersion()
        {
            try
            {
                var pi = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(TranslatorWindow).Assembly);
                if (pi != null && !string.IsNullOrEmpty(pi.resolvedPath))
                {
                    var p = System.IO.Path.Combine(pi.resolvedPath, "package.json");
                    if (System.IO.File.Exists(p))
                    {
                        return ScanVersion(System.IO.File.ReadAllText(p));
                    }
                }
            }
            catch
            {
                // 读不到版本不影响使用
            }
            return "";
        }

        static string ScanVersion(string json)
        {
            const char Q = (char)34;
            var key = Q + "version" + Q;
            var i = json.IndexOf(key, System.StringComparison.Ordinal);
            if (i < 0) return "";
            i = json.IndexOf(Q, i + key.Length);
            if (i < 0) return "";
            var j = json.IndexOf(Q, i + 1);
            if (j <= i) return "";
            return json.Substring(i + 1, j - i - 1);
        }

        void Draw()
        {
            EditorGUILayout.LabelField("团子冲击！ " + PackageVersion(), EditorStyles.boldLabel);
            EditorGUILayout.LabelField($"Harmony: {HarmonyLoader.Source}（实例 {(HarmonyLoader.Harmony != null ? "已创建" : "未创建")}）");
            EditorGUILayout.Space();
            EditorGUILayout.Space();

            EditorGUILayout.LabelField("翻译管线", EditorStyles.boldLabel);
            EditorGUILayout.LabelField($"词条: {TextPipeline.EntryCount}    命中: {TextPipeline.HitCount}    未命中: {TextPipeline.MissCount}");
            EditorGUILayout.LabelField($"中文字体: {(FontFixer.HasChineseFont ? "已找到" : "<未找到>")}");

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("在线翻译（以后导入的插件自动翻）", EditorStyles.boldLabel);
            TranslationApi.Enabled = EditorGUILayout.ToggleLeft("启用在线翻译（未命中自动送翻，结果永久缓存）", TranslationApi.Enabled);
            using (new EditorGUI.DisabledScope(!TranslationApi.Enabled))
            {
                TranslationApi.CurrentBackend = (TranslationApi.Backend)EditorGUILayout.EnumPopup("翻译源", TranslationApi.CurrentBackend);

                if (TranslationApi.CurrentBackend == TranslationApi.Backend.Deepl ||
                    TranslationApi.CurrentBackend == TranslationApi.Backend.Baidu)
                    TranslationApi.ApiKey = EditorGUILayout.PasswordField("AppID / AuthKey", TranslationApi.ApiKey);

                if (TranslationApi.CurrentBackend == TranslationApi.Backend.Baidu)
                    TranslationApi.ApiSecret = EditorGUILayout.PasswordField("AppSecret", TranslationApi.ApiSecret);

                if (TranslationApi.CurrentBackend == TranslationApi.Backend.OpenAICompat)
                {
                    TranslationApi.ApiEndpoint = EditorGUILayout.TextField("接口地址", TranslationApi.ApiEndpoint);
                    TranslationApi.ApiKey = EditorGUILayout.PasswordField("API Key", TranslationApi.ApiKey);
                }
            }

            EditorGUILayout.LabelField($"已缓存译文: {TranslationApi.CachedCount}    排队: {TranslationApi.QueuedCount}    失败: {TranslationApi.FailedCount}");
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("立即拉取译文")) TranslationApi.Drain();
                if (GUILayout.Button("清空译文缓存")) TranslationApi.ClearCache();
            }

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("插件目录级汉化（自带词典 / 写死菜单的插件）", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("改前自动留 .ygzh.bak，可一键还原。", EditorStyles.miniLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("一键全翻译本项目插件"))
                {
                    var r = CatalogPatcher.PatchAll();
                    EditorUtility.DisplayDialog("完成", string.IsNullOrEmpty(r.Report) ? "没发现需要处理的插件" : r.Report, "好");
                }

                if (GUILayout.Button("一键还原"))
                {
                    if (EditorUtility.DisplayDialog("还原", "把所有 .ygzh.bak 备份还原回去？", "还原", "取消"))
                        EditorUtility.DisplayDialog("完成", $"已还原 {CatalogPatcher.RestoreAll()} 个文件", "好");
                }
            }
            EditorGUILayout.LabelField("探针状态", EditorStyles.boldLabel);
            EditorGUILayout.LabelField($"探针模式: {HookHost.ProbeMode}    已启用: {HookHost.Enabled}");
            EditorGUILayout.LabelField($"PatchedCount: {HookHost.PatchedCount}");
            EditorGUILayout.LabelField($"命中次数: {HookHost.HitCount}    去重截获: {HookHost.CaptureCount}");
            // R14：EnteredCount 是 Prefix 被真正进入的次数。已停用时它还在涨，就说明 detour 没被摘干净。
            EditorGUILayout.LabelField($"Prefix 进入次数: {HookHost.EnteredCount}    累计异常: {HookHost.TotalErrors}");
            EditorGUILayout.LabelField($"probe.log: {HookHost.ProbeLogPath ?? "<未启用>"}");

            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button(HookHost.Enabled ? "重新加载探针" : "启用探针"))
                {
                    HookHost.ProbeMode = true;
                    HookHost.Enable();
                }

                if (GUILayout.Button("停用")) HookHost.Disable();
                if (GUILayout.Button("清空统计")) HookHost.ClearStats();
            }

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("最近 10 条文本（新 -> 旧）", EditorStyles.boldLabel);

            var recent = HookHost.RecentSnapshot();
            if (recent.Length == 0)
            {
                EditorGUILayout.LabelField("（暂无）");
            }
            else
            {
                for (var i = recent.Length - 1; i >= 0; i--)
                    EditorGUILayout.LabelField("• " + recent[i]);
            }
        }
    }
}
