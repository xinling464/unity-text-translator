using System;
using System.Reflection;
using UnityEngine;
using UnityEngine.UIElements;

namespace YGTextTranslator
{
    /// <summary>
    /// UI Toolkit 层：Unity 2022 起很多面板（Modular Avatar、NDMF、VRChat SDK 新版界面）
    /// 走的是 UI Toolkit 而不是 IMGUI，GUI.Label 那套 patch 抓不到它们。
    /// 这里 patch <c>TextElement.text</c> 的 setter，在赋值时把英文/日文换成中文。
    /// 因为我们改的是入参而不是再调一次 setter，所以不会有重入问题。
    /// </summary>
    internal static class UiTextHook
    {
        internal static bool Patched { get; private set; }

        internal static bool TryInit()
        {
            if (Patched) return true;
            try
            {
                var prop = typeof(TextElement).GetProperty("text", BindingFlags.Public | BindingFlags.Instance);
                var setter = prop != null ? prop.GetSetMethod() : null;
                if (setter == null)
                {
                    Debug.LogWarning("[YG] UI Toolkit：找不到 TextElement.text 的 setter，跳过");
                    return false;
                }

                var prefix = typeof(UiTextHook).GetMethod(nameof(Prefix), BindingFlags.Static | BindingFlags.NonPublic);
                Patched = HarmonyLoader.Patch(setter, prefix);
                Debug.Log($"[YG] UI Toolkit 层：TextElement.text {(Patched ? "已挂上" : "挂载失败")}");
                return Patched;
            }
            catch (Exception e)
            {
                Debug.LogWarning("[YG] UI Toolkit 层初始化失败：" + e.Message);
                return false;
            }
        }


        /// <summary>
        /// 把当前已经存在的 UI Toolkit 文字扫一遍换掉。
        /// setter patch 只能拦住「之后才赋值」的文字；VRChat SDK 这类在窗口构造时就写死 text 的，
        /// 必须靠这一遍主动改写，否则界面永远停在英文。
        /// </summary>
        internal static int Sweep()
        {
            var changed = 0;
            if (!HookHost.Enabled) return 0;

            try
            {
                var windows = Resources.FindObjectsOfTypeAll<UnityEditor.EditorWindow>();
                foreach (var w in windows)
                {
                    if (w == null) continue;
                    VisualElement root;
                    try { root = w.rootVisualElement; }
                    catch { continue; }
                    if (root == null) continue;

                    System.Collections.Generic.List<TextElement> list;
                    try { list = root.Query<TextElement>().ToList(); }
                    catch { continue; }

                    foreach (var te in list)
                    {
                        if (te == null) continue;
                        // 输入类控件不动：TextField / TextFieldBase 里的 text 是用户数据
                        if (te is UnityEngine.UIElements.TextField) continue;
                        var t = te.text;
                        if (string.IsNullOrEmpty(t)) continue;
                        if (!TextPipeline.ShouldTranslate(t)) continue;

                        var zh = TextPipeline.Translate(t);
                        if (string.IsNullOrEmpty(zh) || zh == t) continue;

                        try
                        {
                            TextPipeline.Suppress = true;
                            te.text = zh;
                            changed++;
                        }
                        catch
                        {
                            // 单个元素失败不影响整体
                        }
                        finally
                        {
                            TextPipeline.Suppress = false;
                        }
                    }
                }
            }
            catch
            {
                // Sweep 绝不能把异常抛给调用方
            }

            if (changed > 0)
            {
                try { UnityEditorInternal.InternalEditorUtility.RepaintAllViews(); } catch { }
                Debug.Log("[YG] UI Toolkit 扫描改写：" + changed + " 处");
            }
            return changed;
        }

        static void Prefix(ref string value)
        {
            if (string.IsNullOrEmpty(value)) return;
            if (!HookHost.Enabled) return;

            try
            {
                if (TextPipeline.Suppress) return;
                if (!TextPipeline.ShouldTranslate(value)) return;

                var zh = TextPipeline.Translate(value);
                if (!string.IsNullOrEmpty(zh) && !ReferenceEquals(zh, value) && zh != value)
                {
                    value = zh;
                }
            }
            catch
            {
                // 绘制路径绝不能让异常冒出去
            }
        }
    }
}
