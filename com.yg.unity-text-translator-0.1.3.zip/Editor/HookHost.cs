﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading;
using UnityEditor;
using UnityEngine;

namespace YGTextTranslator
{
    /// <summary>
    /// 接管版 GUI 文本钩子：Patch 8 个 GUI/GUILayout 文本方法，命中时先记录，再按词典把英文替换成中文。
    ///
    /// T4 起 Prefix 返回 bool：true = 放行原方法（未命中/已禁用/中文），false = 原方法跳过，由 Prefix 自己
    /// 用 GUIContent + 中文字体重画。重画会再次进入被 patch 的重载，因此整段用 TextPipeline.Suppress
    /// 包住，保证只翻一次、不会无限重入（R12）。
    /// 参数注入：GUI.Label/Box 的文本是第 1 个参数（__1，第 0 个是 Rect），
    /// GUILayout.Label 的文本是第 0 个参数（__0）。Prefix 一律用 __N 序号注入，
    /// 避免依赖 Unity 内部的参数名（text/content）。
    ///
    /// 安全约束：
    /// - 每个 Prefix 自带 try/catch，异常不逃逸到 Unity 的 GUI 循环；
    /// - 连续 3 次 Prefix 异常 -> 自动 Disable + LogError（成功调用清零）；
    /// - OnText 订阅者异常单独隔离，不计入熔断；
    /// - Disable 幂等，且清空 patch 记账，Enable 可重复调用。
    /// </summary>
    internal static class HookHost
    {
        const int RecentCapacity = 10;
        // Important 4：Inspector 一帧有几十到上百条不同文本，窗口太小会把老文本挤出后重新计一次。
        // 4096 条的字符串内存开销可以忽略，换得 CaptureCount 真正接近「唯一文本数」。
        const int DedupWindow = 4096;
        const int ProbeLogQueueMaxChars = 256 * 1024;
        const long ProbeLogMaxBytes = 8L * 1024 * 1024;
        const int ErrorTripThreshold = 3;

        const string KeyStr0 = nameof(StrPrefix0);
        const string KeyStr1 = nameof(StrPrefix1);
        const string KeyStr1Styled = nameof(StrPrefix1Styled);
        const string KeyContent0 = nameof(ContentPrefix0);
        const string KeyContent1 = nameof(ContentPrefix1);
        const string KeyContent1Styled = nameof(ContentPrefix1Styled);
        const string KeyBoxStr1 = nameof(BoxStrPrefix1);
        const string KeyBoxContent1 = nameof(BoxContentPrefix1);
        static readonly object Gate = new object();
        static readonly HashSet<string> PatchedKeys = new HashSet<string>();
        static readonly List<string> Recent = new List<string>(RecentCapacity);
        static readonly Queue<string> DedupOrder = new Queue<string>(DedupWindow);
        static readonly HashSet<string> DedupSet = new HashSet<string>();
        // Important 1：熔断按 prefix 分桶。全局单计数会被其它 prefix 的成功调用清零，
        // 真实 Inspector 里 Layout/Repaint 交错，>=3 永远到不了。
        static readonly Dictionary<string, int> ErrorBuckets = new Dictionary<string, int>();

        static int _captureCount;
        static int _hitCount;
        static int _enteredCount;
        static int _totalErrors;
        static bool _logDrainHooked;
        static string _probeLogPath;
        static long _probeLogBytes;
        static bool _probeLogTruncated;
        static bool _probeLogWarned;
        static bool _suppressCapture;
        // Minor 6：熔断排队的标记。避免同一时刻排多次 EditorApplication.delayCall。
        static bool _tripScheduled;

        // T4 review：一次 GUI.Label(string) 未命中会转发到 GUIContent 重载。线程内哨兵只消费一次，
        // 让同一次绘制链的第二个 Prefix 直接放行，不重复记 miss / 不重复 Note。
        [ThreadStatic] static string _forwardedText;
        [ThreadStatic] static int _forwardedFrame;

        // 绘制异常只记一条 warning，不进熔断桶。
        static readonly HashSet<string> DrawWarnings = new HashSet<string>();

        const int ReplacementCacheCapacity = 1024;
        static readonly Dictionary<ContentKey, GUIContent> ReplacementCache = new Dictionary<ContentKey, GUIContent>();

        struct ContentKey : IEquatable<ContentKey>
        {
            public string Text;
            public Texture Image;
            public string Tooltip;
            public int StyleHash;

            public ContentKey(string text, Texture image, string tooltip, int styleHash)
            {
                Text = text;
                Image = image;
                Tooltip = tooltip;
                StyleHash = styleHash;
            }

            public bool Equals(ContentKey other)
            {
                return StyleHash == other.StyleHash
                    && ReferenceEquals(Image, other.Image)
                    && string.Equals(Text, other.Text, StringComparison.Ordinal)
                    && string.Equals(Tooltip, other.Tooltip, StringComparison.Ordinal);
            }

            public override bool Equals(object obj)
            {
                return obj is ContentKey && Equals((ContentKey)obj);
            }

            public override int GetHashCode()
            {
                unchecked
                {
                    var hash = Text != null ? Text.GetHashCode() : 0;
                    hash = (hash * 397) ^ (Image != null ? Image.GetHashCode() : 0);
                    hash = (hash * 397) ^ (Tooltip != null ? Tooltip.GetHashCode() : 0);
                    hash = (hash * 397) ^ StyleHash;
                    return hash;
                }
            }
        }

        /// <summary>是否已挂上 patch（Enable 成功且尚未 Disable）。</summary>
        public static bool Enabled { get; private set; }

        /// <summary>探针模式：开启时被截获的文本追加写 probe.log。</summary>
        public static bool ProbeMode { get; set; }

        /// <summary>成功挂上的 patch 条数（按 (original,prefix) 去重）。</summary>
        public static int PatchedCount { get { lock (Gate) return PatchedKeys.Count; } }

        /// <summary>
        /// 去重后的截获文本条数（同一文本在 4096 条先进先出窗口内只计一次）。
        /// 超长列表滚动时仍可能缓慢虚涨：淘汰的文本会被重新计一次；T4 替换阶段按文本 hash 缓存译文，不依赖本计数。
        /// </summary>
        public static int CaptureCount { get { lock (Gate) return _captureCount; } }

        /// <summary>所有命中次数（含重复，用于观察 Layout/Repaint 双跑）。</summary>
        public static int HitCount { get { lock (Gate) return _hitCount; } }

        /// <summary>累计失败次数（所有 prefix 相加，测试可读）。</summary>
        public static int TotalErrors { get { lock (Gate) return _totalErrors; } }

        /// <summary>各 prefix 失败桶里的最大值（0 表示当前没有失败在累积）。</summary>
        public static int ConsecutiveErrors
        {
            get
            {
                lock (Gate)
                {
                    var max = 0;
                    foreach (var pair in ErrorBuckets)
                        if (pair.Value > max) max = pair.Value;
                    return max;
                }
            }
        }

        /// <summary>
        /// R14：Prefix 被进入的累计次数（在每个 Prefix 的第一行无条件自增，先于 Enabled 判断）。
        /// Disable() 之后再调一次 GUI.Label / GUILayout.Label，这个值必须不增——这才是 detour
        /// 真被摘掉的证据，而不是只看插件自家的 PatchedCount 账本。
        /// </summary>
        public static int EnteredCount { get { return Volatile.Read(ref _enteredCount); } }

        /// <summary>probe.log 的绝对路径（未启用探针时为 null）。</summary>
        public static string ProbeLogPath { get { return _probeLogPath; } }

        /// <summary>抑制捕获（探针窗口绘制自身 UI 时使用，避免自我增殖）。</summary>
        public static bool SuppressCapture
        {
            get { return _suppressCapture; }
            set { _suppressCapture = value; }
        }

        /// <summary>命中一条文本时触发；订阅者异常会被隔离。</summary>
        public static event Action<string> OnText;

        // ---------------------------------------------------------------- Enable / Disable

        /// <summary>初始化 Harmony 并挂上全部目标 patch。重复调用不会重复计数。</summary>
        public static void Enable()
        {
            // 不做 Enabled 早退：去重保证不会重复 patch，失败项可以在这里重试补齐。

            // 词典与字体预热放在 Enable（非 GUI 路径），避免第一次 Prefix 命中时做文件 IO / 字体创建。
            TextPipeline.EnsureLoaded();
            FontFixer.Warmup();

            if (!HarmonyLoader.TryInit(out var error))
            {
                Debug.LogError($"[YGTextTranslator] HookHost.Enable 失败：Harmony 未就绪 {error}");
                return;
            }

            if (ProbeMode) EnsureProbeLog();
            HookLogDrain(); // Important 3：日志排空只在这里接上，Patch 调用路径不碰文件 IO

            var added = 0;
            var failed = 0;
            foreach (var spec in Targets())
            {
                if (spec.Original == null || spec.Prefix == null)
                {
                    failed++;
                    Debug.LogError($"[YGTextTranslator] 目标缺失：{spec.Key}（original={spec.Original}, prefix={spec.Prefix}）");
                    continue;
                }

                lock (Gate)
                {
                    if (PatchedKeys.Contains(spec.Key)) continue;
                    PatchedKeys.Add(spec.Key);
                }

                if (HarmonyLoader.Patch(spec.Original, spec.Prefix))
                {
                    added++;
                }
                else
                {
                    lock (Gate) PatchedKeys.Remove(spec.Key);
                    failed++;
                }
            }

            Enabled = PatchedCount > 0;
            Debug.Log($"[YGTextTranslator] HookHost.Enable 完成：新增 patch {added}，失败 {failed}，PatchedCount={PatchedCount}");
        }

        /// <summary>撤掉本插件所有 patch。幂等；重复调用安全。</summary>
        public static void Disable()
        {
            UnhookLogDrain();

            // Minor 3（re-review）：UnpatchAll 无条件执行。Disable 的契约是「撤干净」，不是
            // 「按账本撤」——账本（Enabled / PatchedKeys）可能因部分失败、或未来第二条 patch
            // 路径而不准，撤销不能依赖它。只有 Debug.Log 用 hadState 门控压噪。
            var hadState = Enabled || PatchedCount > 0;

            Enabled = false;
            HarmonyLoader.UnpatchAll();

            lock (Gate)
            {
                PatchedKeys.Clear();
                ErrorBuckets.Clear();
            }

            FlushProbeLog();
            Debug.Log($"[YGTextTranslator] HookHost.Disable 完成：PatchedCount={PatchedCount}");
        }

        /// <summary>清空统计与最近列表（不清 patch）。</summary>
        public static void ClearStats()
        {
            lock (Gate)
            {
                _captureCount = 0;
                _hitCount = 0;
                Recent.Clear();
                DedupOrder.Clear();
                DedupSet.Clear();
                ErrorBuckets.Clear();
                _totalErrors = 0;
            }
        }

        /// <summary>最近截获文本的快照（旧 -> 新，最多 10 条）。</summary>
        public static string[] RecentSnapshot()
        {
            lock (Gate) return Recent.ToArray();
        }

        /// <summary>删除 probe.log 并重置写入状态（探针自检前调用）。</summary>
        public static void ResetProbeLog()
        {
            try
            {
                var path = ResolveProbeLogPath();
                if (File.Exists(path)) File.Delete(path);
                var header = $"===== 探针会话 {DateTime.Now:yyyy-MM-dd HH:mm:ss} ====={Environment.NewLine}";
                File.AppendAllText(path, header, Encoding.UTF8);
                _probeLogPath = path;
                // Minor 2：会话头本身也占字节，按真实文件长度起步，否则 8MB 上限会略微超。
                _probeLogBytes = new FileInfo(path).Length;
                _probeLogTruncated = false;
                _probeLogWarned = false;
                lock (Gate)
                {
                    LogBuffer.Clear();
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[YGTextTranslator] 重置 probe.log 失败：{ex.Message}");
            }
        }

        // ---------------------------------------------------------------- 测试入口

        /// <summary>
        /// 测试入口（batchmode 用）：走与 Prefix 完全相同的记录逻辑，返回传入的值。
        /// 用于断言「OnText 收到文本」且「ref 值未被修改」。
        /// </summary>
        internal static string __TestFire(string text)
        {
            // T3 回归入口：保持「只记录、不改值」的旧语义，不经过替换路径。
            Interlocked.Increment(ref _enteredCount);
            var value = text;
            try
            {
                if (Enabled && ShouldCapture() && !string.IsNullOrEmpty(value)) Record(value);
                NoteSuccess(KeyStr1);
            }
            catch (Exception ex)
            {
                SafeNoteFailure(KeyStr1, ex);
            }
            return value;
        }

        /// <summary>
        /// 测试入口：指定 prefix 的失败桶连续累加 N 次，用于验证「同一 prefix 连续 3 次异常 → 自动停用」。
        /// prefixKey 用 GUI.Label(Rect,string) 之类真实 key，或直接用 HookHost 内部的 Key 常量名。
        /// </summary>
        internal static void __TestRaiseErrors(string prefixKey, int times)
        {
            for (var i = 0; i < times; i++)
                NoteFailure(prefixKey, new InvalidOperationException($"probe-injected-error-{i + 1}"));
        }

        /// <summary>测试入口：指定 prefix 报一次成功（用于验证「其它 prefix 成功不会清掉本桶」）。</summary>
        internal static void __TestNoteSuccess(string prefixKey)
        {
            NoteSuccess(prefixKey);
        }

        /// <summary>测试入口：走「是否替换 + 译文」决策，但不实际绘制。T4 探针用。</summary>
        internal static string __TestIntercept(string text)
        {
            if (!Enabled) return text;
            string zh;
            return TryGetTranslation(text, out zh) ? zh : text;
        }

        /// <summary>测试用：暴露内部 Key 常量，避免测试里硬编码字符串。</summary>
        internal static readonly string TestKeyStr1 = KeyStr1;
        internal static readonly string TestKeyContent1 = KeyContent1;

        // ---------------------------------------------------------------- Patch 目标表

        struct TargetSpec
        {
            public string Key;
            public MethodInfo Original;
            public MethodInfo Prefix;
        }

        static TargetSpec[] _targets;

        static TargetSpec[] Targets()
        {
            if (_targets != null) return _targets;

            var list = new List<TargetSpec>
            {
                Spec("GUI.Label(Rect,string)", typeof(GUI), "Label", new[] { typeof(Rect), typeof(string) }, nameof(StrPrefix1)),
                Spec("GUI.Label(Rect,GUIContent)", typeof(GUI), "Label", new[] { typeof(Rect), typeof(GUIContent) }, nameof(ContentPrefix1)),
                Spec("GUI.Label(Rect,string,GUIStyle)", typeof(GUI), "Label", new[] { typeof(Rect), typeof(string), typeof(GUIStyle) }, nameof(StrPrefix1Styled)),
                Spec("GUI.Label(Rect,GUIContent,GUIStyle)", typeof(GUI), "Label", new[] { typeof(Rect), typeof(GUIContent), typeof(GUIStyle) }, nameof(ContentPrefix1Styled)),
                Spec("GUI.Box(Rect,string)", typeof(GUI), "Box", new[] { typeof(Rect), typeof(string) }, nameof(BoxStrPrefix1)),
                Spec("GUI.Box(Rect,GUIContent)", typeof(GUI), "Box", new[] { typeof(Rect), typeof(GUIContent) }, nameof(BoxContentPrefix1)),
                Spec("GUILayout.Label(string,GUILayoutOption[])", typeof(GUILayout), "Label", new[] { typeof(string), typeof(GUILayoutOption[]) }, nameof(StrPrefix0)),
                Spec("GUILayout.Label(GUIContent,GUILayoutOption[])", typeof(GUILayout), "Label", new[] { typeof(GUIContent), typeof(GUILayoutOption[]) }, nameof(ContentPrefix0)),
                // EditorGUI 层：Inspector 的字段标签。LabelField/PrefixLabel 带文本的重载共 8 个，
                // PrefixLabel 还有带 controlID 的版本（Vector3Field 等复合控件走这条），必须逐个挂 __N。
                // 注：不能用 object[] __args 通吃，NDMF 自带的 Harmony 2.0.5 会报
                // "Parameter __args does not contain a valid index"。
                Spec("EditorGUI.LabelField(Rect,string)", typeof(EditorGUI), "LabelField", new[] { typeof(Rect), typeof(string) }, nameof(StrPrefix1)),
                Spec("EditorGUI.LabelField(Rect,string,GUIStyle)", typeof(EditorGUI), "LabelField", new[] { typeof(Rect), typeof(string), typeof(GUIStyle) }, nameof(StrPrefix1Styled)),
                Spec("EditorGUI.LabelField(Rect,GUIContent)", typeof(EditorGUI), "LabelField", new[] { typeof(Rect), typeof(GUIContent) }, nameof(ContentPrefix1)),
                Spec("EditorGUI.LabelField(Rect,GUIContent,GUIStyle)", typeof(EditorGUI), "LabelField", new[] { typeof(Rect), typeof(GUIContent), typeof(GUIStyle) }, nameof(ContentPrefix1Styled)),
                // PrefixLabel 返回 Rect（label 之后剩下的区域），调用方靠它定位输入框；
                // 所以这里**只能改入参、必须 return true**，否则返回 default(Rect) 会让输入框消失。
                Spec("EditorGUI.PrefixLabel(Rect,GUIContent)", typeof(EditorGUI), "PrefixLabel", new[] { typeof(Rect), typeof(GUIContent) }, nameof(PrefixLabelContent)),
                Spec("EditorGUI.PrefixLabel(Rect,GUIContent,GUIStyle)", typeof(EditorGUI), "PrefixLabel", new[] { typeof(Rect), typeof(GUIContent), typeof(GUIStyle) }, nameof(PrefixLabelContentStyled)),
                Spec("EditorGUI.PrefixLabel(Rect,int,GUIContent)", typeof(EditorGUI), "PrefixLabel", new[] { typeof(Rect), typeof(int), typeof(GUIContent) }, nameof(PrefixLabelContentId)),
                Spec("EditorGUI.PrefixLabel(Rect,int,GUIContent,GUIStyle)", typeof(EditorGUI), "PrefixLabel", new[] { typeof(Rect), typeof(int), typeof(GUIContent), typeof(GUIStyle) }, nameof(PrefixLabelContentIdStyled)),
                // 控件层：Toggle / Button / Foldout 的文字不走 GUI.Label，而是自己用 GUIStyle.Draw，
                // 所以必须单独 patch；而且只能改入参、返回 true（返回 false 会让开关/按钮点不动）。
                Spec("GUILayout.Toggle(bool,string,GUILayoutOption[])", typeof(GUILayout), "Toggle", new[] { typeof(bool), typeof(string), typeof(GUILayoutOption[]) }, nameof(ToggleStr1)),
                Spec("GUILayout.Toggle(bool,GUIContent,GUILayoutOption[])", typeof(GUILayout), "Toggle", new[] { typeof(bool), typeof(GUIContent), typeof(GUILayoutOption[]) }, nameof(ToggleContent1)),
                Spec("GUILayout.Button(string,GUILayoutOption[])", typeof(GUILayout), "Button", new[] { typeof(string), typeof(GUILayoutOption[]) }, nameof(ButtonStr0)),
                Spec("GUILayout.Button(GUIContent,GUILayoutOption[])", typeof(GUILayout), "Button", new[] { typeof(GUIContent), typeof(GUILayoutOption[]) }, nameof(ButtonContent0)),
                Spec("GUILayout.Foldout(bool,string,GUIStyle)", typeof(GUILayout), "Foldout", new[] { typeof(bool), typeof(string), typeof(GUIStyle) }, nameof(FoldoutStr1)),
                Spec("GUILayout.Foldout(bool,GUIContent,GUIStyle)", typeof(GUILayout), "Foldout", new[] { typeof(bool), typeof(GUIContent), typeof(GUIStyle) }, nameof(FoldoutContent1)),
                Spec("GUILayout.Foldout(bool,string,bool,GUIStyle)", typeof(GUILayout), "Foldout", new[] { typeof(bool), typeof(string), typeof(bool), typeof(GUIStyle) }, nameof(FoldoutStr2)),
                Spec("GUI.Toggle(Rect,bool,string,GUIStyle)", typeof(GUI), "Toggle", new[] { typeof(Rect), typeof(bool), typeof(string), typeof(GUIStyle) }, nameof(GuiToggleStr2)),
                Spec("GUI.Toggle(Rect,bool,GUIContent,GUIStyle)", typeof(GUI), "Toggle", new[] { typeof(Rect), typeof(bool), typeof(GUIContent), typeof(GUIStyle) }, nameof(GuiToggleContent2)),
                Spec("GUI.Button(Rect,GUIContent,GUIStyle)", typeof(GUI), "Button", new[] { typeof(Rect), typeof(GUIContent), typeof(GUIStyle) }, nameof(GuiButtonContent1)),
                Spec("GUI.Foldout(Rect,bool,GUIContent,GUIStyle)", typeof(GUI), "Foldout", new[] { typeof(Rect), typeof(bool), typeof(GUIContent), typeof(GUIStyle) }, nameof(GuiFoldoutContent2)),
            };

            _targets = list.ToArray();
            return _targets;
        }

        // ---- 控件层：只改入参，绝不接管绘制（一律 return true 让 Unity 自己画） ----
        static void TryReplace(ref string s)
        {
            try
            {
                if (!Enabled || TextPipeline.Suppress) return;
                if (!TextPipeline.ShouldTranslate(s)) return;
                var zh = TextPipeline.Translate(s);
                if (!string.IsNullOrEmpty(zh) && zh != s) s = zh;
            }
            catch
            {
                // 控件层绝不把异常抛回 OnGUI：宁可显示英文，也不能让控件（输入框/按钮）消失。
            }
        }

        static void TryReplace(ref GUIContent c)
        {
            try
            {
                if (c == null || !Enabled || TextPipeline.Suppress) return;
                if (!TextPipeline.ShouldTranslate(c.text)) return;
                var zh = TextPipeline.Translate(c.text);
                if (!string.IsNullOrEmpty(zh) && zh != c.text) c = new GUIContent(zh, c.image, c.tooltip);
            }
            catch
            {
            }
        }

        static bool ToggleStr1(bool __0, ref string __1, GUILayoutOption[] __2) { TryReplace(ref __1); return true; }
        static bool ToggleContent1(bool __0, ref GUIContent __1, GUILayoutOption[] __2) { TryReplace(ref __1); return true; }
        static bool ButtonStr0(ref string __0, GUILayoutOption[] __1) { TryReplace(ref __0); return true; }
        static bool ButtonContent0(ref GUIContent __0, GUILayoutOption[] __1) { TryReplace(ref __0); return true; }
        static bool FoldoutStr1(bool __0, ref string __1, GUIStyle __2) { TryReplace(ref __1); return true; }
        static bool FoldoutContent1(bool __0, ref GUIContent __1, GUIStyle __2) { TryReplace(ref __1); return true; }
        static bool FoldoutStr2(bool __0, ref string __1, bool __2, GUIStyle __3) { TryReplace(ref __1); return true; }
        static bool GuiToggleStr2(Rect __0, bool __1, ref string __2, GUIStyle __3) { TryReplace(ref __2); return true; }
        static bool GuiToggleContent2(Rect __0, bool __1, ref GUIContent __2, GUIStyle __3) { TryReplace(ref __2); return true; }
        static bool GuiButtonContent1(Rect __0, ref GUIContent __1, GUIStyle __2) { TryReplace(ref __1); return true; }
        static bool GuiFoldoutContent2(Rect __0, bool __1, ref GUIContent __2, GUIStyle __3) { TryReplace(ref __2); return true; }

        // ---- PrefixLabel 专用：它返回 Rect，绝不能接管绘制，只能改文本 ----
        static bool PrefixLabelContent(Rect __0, ref GUIContent __1) { TryReplace(ref __1); return true; }
        static bool PrefixLabelContentStyled(Rect __0, ref GUIContent __1, GUIStyle __2) { TryReplace(ref __1); return true; }
        static bool PrefixLabelContentId(Rect __0, int __1, ref GUIContent __2) { TryReplace(ref __2); return true; }
        static bool PrefixLabelContentIdStyled(Rect __0, int __1, ref GUIContent __2, GUIStyle __3) { TryReplace(ref __2); return true; }

        static bool ContentPrefix2Id(Rect __0, int __1, ref GUIContent __2)
        {
            Interlocked.Increment(ref _enteredCount);
            return HandleGuiContent(__0, ref __2, null, KeyContent1, false);
        }

        static bool ContentPrefix2IdStyled(Rect __0, int __1, ref GUIContent __2, GUIStyle __3)
        {
            Interlocked.Increment(ref _enteredCount);
            return HandleGuiContent(__0, ref __2, __3, KeyContent1Styled, false);
        }

        static TargetSpec Spec(string key, Type type, string method, Type[] args, string prefixName)
        {
            var original = type.GetMethod(method, BindingFlags.Public | BindingFlags.Static, null, args, null);
            var prefix = typeof(HookHost).GetMethod(prefixName, BindingFlags.Static | BindingFlags.NonPublic);
            return new TargetSpec { Key = key + " <- " + prefixName, Original = original, Prefix = prefix };
        }

        // ---------------------------------------------------------------- Prefix（T4：记录 + 替换；重入用 Suppress 抑制）

        static bool StrPrefix0(ref string __0, GUILayoutOption[] __1)
        {
            Interlocked.Increment(ref _enteredCount); // R14
            return HandleLayoutString(ref __0, __1, KeyStr0);
        }

        static bool ContentPrefix0(ref GUIContent __0, GUILayoutOption[] __1)
        {
            Interlocked.Increment(ref _enteredCount); // R14
            return HandleLayoutContent(ref __0, __1, KeyContent0);
        }

        static bool StrPrefix1(Rect __0, ref string __1)
        {
            Interlocked.Increment(ref _enteredCount); // R14
            return HandleGuiString(__0, ref __1, null, KeyStr1, false);
        }

        static bool ContentPrefix1(Rect __0, ref GUIContent __1)
        {
            Interlocked.Increment(ref _enteredCount); // R14
            return HandleGuiContent(__0, ref __1, null, KeyContent1, false);
        }

        static bool StrPrefix1Styled(Rect __0, ref string __1, GUIStyle __2)
        {
            Interlocked.Increment(ref _enteredCount); // R14
            return HandleGuiString(__0, ref __1, __2, KeyStr1Styled, false);
        }

        static bool ContentPrefix1Styled(Rect __0, ref GUIContent __1, GUIStyle __2)
        {
            Interlocked.Increment(ref _enteredCount); // R14
            return HandleGuiContent(__0, ref __1, __2, KeyContent1Styled, false);
        }

        static bool BoxStrPrefix1(Rect __0, ref string __1)
        {
            Interlocked.Increment(ref _enteredCount); // R14
            return HandleGuiString(__0, ref __1, null, KeyBoxStr1, true);
        }

        static bool BoxContentPrefix1(Rect __0, ref GUIContent __1)
        {
            Interlocked.Increment(ref _enteredCount); // R14
            return HandleGuiContent(__0, ref __1, null, KeyBoxContent1, true);
        }

        // ---------------------------------------------------------------- 替换实现

        /// <summary>只在 OnGUI 内访问 GUI.skin；batchmode 下 GUI.skin 会抛，回退到传入样式。</summary>
        static GUIStyle ResolveStyle(GUIStyle style, bool box)
        {
            if (!box && style != null) return style;
            if (Event.current == null) return style;
            try
            {
                if (GUI.skin == null) return style;
                return box ? GUI.skin.box : GUI.skin.label;
            }
            catch
            {
                return style;
            }
        }

        static bool HandleGuiString(Rect rect, ref string text, GUIStyle style, string key, bool box)
        {
            try
            {
                if (!TextPipeline.Suppress && ConsumeForwarded(text)) return true;
                if (Enabled && !TextPipeline.Suppress && ShouldCapture() && !string.IsNullOrEmpty(text)) Record(text);

                string zh = null;
                var shouldTranslate = false;
                var translated = Enabled && TryGetTranslation(text, out zh, out shouldTranslate);
                if (!translated)
                {
                    if (shouldTranslate) MarkForwarded(text);
                    NoteSuccess(key);
                    return true;
                }

                var targetStyle = ResolveStyle(style, box);

                var previousSuppress = TextPipeline.Suppress;
                TextPipeline.Suppress = true;
                try
                {
                    var content = GetReplacementContent(zh, null, null, targetStyle);
                    var clone = FontFixer.Clone(targetStyle, EffectiveFontSize(targetStyle));
                    if (box) GUI.Box(rect, content, clone);
                    else GUI.Label(rect, content, clone);
                    NoteSuccess(key);
                    return false;
                }
                catch (Exception ex)
                {
                    LogDrawWarning(key, ex);
                    try
                    {
                        // Suppress 仍为 true：这里重画原文，避免框架原方法再次进入翻译（R12）。
                        if (box) GUI.Box(rect, GetReplacementContent(text, null, null, targetStyle), targetStyle);
                        else GUI.Label(rect, GetReplacementContent(text, null, null, targetStyle), targetStyle);
                    }
                    catch
                    {
                        // 原文也画不了（batchmode 常态）：放弃这一帧，但不把异常抛回 Unity。
                    }
                    return false;
                }
                finally
                {
                    TextPipeline.Suppress = previousSuppress;
                }
            }
            catch (Exception ex)
            {
                SafeNoteFailure(key, ex);
                return true;
            }
        }

        static bool HandleGuiContent(Rect rect, ref GUIContent content, GUIStyle style, string key, bool box)
        {
            try
            {
                if (!TextPipeline.Suppress && ConsumeForwarded(content != null ? content.text : null)) return true;
                if (Enabled && !TextPipeline.Suppress && ShouldCapture() && content != null && !string.IsNullOrEmpty(content.text)) Record(content.text);

                string zh = null;
                var shouldTranslate = false;
                var translated = Enabled && content != null && TryGetTranslation(content.text, out zh, out shouldTranslate);
                if (!translated)
                {
                    if (shouldTranslate && !box) MarkForwarded(content != null ? content.text : null);
                    NoteSuccess(key);
                    return true;
                }

                var targetStyle = ResolveStyle(style, box);
                var replacement = GetReplacementContent(zh, content.image, content.tooltip, targetStyle);

                var previousSuppress = TextPipeline.Suppress;
                TextPipeline.Suppress = true;
                try
                {
                    var clone = FontFixer.Clone(targetStyle, EffectiveFontSize(targetStyle));
                    if (box) GUI.Box(rect, replacement, clone);
                    else GUI.Label(rect, replacement, clone);
                    NoteSuccess(key);
                    return false;
                }
                catch (Exception ex)
                {
                    LogDrawWarning(key, ex);
                    try
                    {
                        // Suppress 仍为 true：回退原文，防止框架原方法再翻一次。
                        if (box) GUI.Box(rect, content, targetStyle);
                        else GUI.Label(rect, content, targetStyle);
                    }
                    catch
                    {
                    }
                    return false;
                }
                finally
                {
                    TextPipeline.Suppress = previousSuppress;
                }
            }
            catch (Exception ex)
            {
                SafeNoteFailure(key, ex);
                return true;
            }
        }

        static bool HandleLayoutString(ref string text, GUILayoutOption[] options, string key)
        {
            try
            {
                if (!TextPipeline.Suppress && ConsumeForwarded(text)) return true;
                if (Enabled && !TextPipeline.Suppress && ShouldCapture() && !string.IsNullOrEmpty(text)) Record(text);

                string zh = null;
                var shouldTranslate = false;
                var translated = Enabled && TryGetTranslation(text, out zh, out shouldTranslate);
                if (!translated)
                {
                    if (shouldTranslate) MarkForwarded(text);
                    NoteSuccess(key);
                    return true;
                }

                var style = ResolveStyle(null, false);
                var previousSuppress = TextPipeline.Suppress;
                TextPipeline.Suppress = true;
                try
                {
                    GUILayout.Label(GetReplacementContent(zh, null, null, style), FontFixer.Clone(style, EffectiveFontSize(style)), options);
                    NoteSuccess(key);
                    return false;
                }
                catch (Exception ex)
                {
                    LogDrawWarning(key, ex);
                    try
                    {
                        // Suppress 仍为 true：回退原文，防止框架原方法再翻一次。
                        GUILayout.Label(new GUIContent(text), style, options);
                    }
                    catch
                    {
                    }
                    return false;
                }
                finally
                {
                    TextPipeline.Suppress = previousSuppress;
                }
            }
            catch (Exception ex)
            {
                SafeNoteFailure(key, ex);
                return true;
            }
        }

        static bool HandleLayoutContent(ref GUIContent content, GUILayoutOption[] options, string key)
        {
            try
            {
                if (!TextPipeline.Suppress && ConsumeForwarded(content != null ? content.text : null)) return true;
                if (Enabled && !TextPipeline.Suppress && ShouldCapture() && content != null && !string.IsNullOrEmpty(content.text)) Record(content.text);

                string zh = null;
                var shouldTranslate = false;
                var translated = Enabled && content != null && TryGetTranslation(content.text, out zh, out shouldTranslate);
                if (!translated)
                {
                    if (shouldTranslate) MarkForwarded(content != null ? content.text : null);
                    NoteSuccess(key);
                    return true;
                }

                var style = ResolveStyle(null, false);
                var replacement = GetReplacementContent(zh, content.image, content.tooltip, style);

                var previousSuppress = TextPipeline.Suppress;
                TextPipeline.Suppress = true;
                try
                {
                    GUILayout.Label(replacement, FontFixer.Clone(style, EffectiveFontSize(style)), options);
                    NoteSuccess(key);
                    return false;
                }
                catch (Exception ex)
                {
                    LogDrawWarning(key, ex);
                    try
                    {
                        GUILayout.Label(content, style, options);
                    }
                    catch
                    {
                    }
                    return false;
                }
                finally
                {
                    TextPipeline.Suppress = previousSuppress;
                }
            }
            catch (Exception ex)
            {
                SafeNoteFailure(key, ex);
                return true;
            }
        }

        static bool TryGetTranslation(string text, out string zh)
        {
            bool shouldTranslate;
            return TryGetTranslation(text, out zh, out shouldTranslate);
        }

        static bool TryGetTranslation(string text, out string zh, out bool shouldTranslate)
        {
            zh = null;
            shouldTranslate = false;
            if (string.IsNullOrEmpty(text)) return false;
            if (TextPipeline.Suppress) return false;
            if (!TextPipeline.ShouldTranslate(text)) return false;

            shouldTranslate = true;
            var translated = TextPipeline.Translate(text);
            if (translated == null || string.Equals(translated, text, StringComparison.Ordinal)) return false;

            zh = translated;
            return true;
        }

        static int EffectiveFontSize(GUIStyle style)
        {
            if (style != null && style.fontSize > 0) return style.fontSize;
            return 12;
        }
        /// <summary>按文本 + 图片 + tooltip + 样式 hash 缓存替换用 GUIContent，避免每帧每 label 新建。</summary>
        static GUIContent GetReplacementContent(string text, Texture image, string tooltip, GUIStyle style)
        {
            var key = new ContentKey(text, image, tooltip, style != null ? style.GetHashCode() : 0);
            lock (Gate)
            {
                GUIContent cached;
                if (ReplacementCache.TryGetValue(key, out cached)) return cached;
                if (ReplacementCache.Count >= ReplacementCacheCapacity) ReplacementCache.Clear();
                cached = new GUIContent(text, image, tooltip);
                ReplacementCache[key] = cached;
                return cached;
            }
        }

        static void MarkForwarded(string text)
        {
            _forwardedText = text;
            try { _forwardedFrame = Time.frameCount; }
            catch { _forwardedFrame = -1; }
        }

        static bool ConsumeForwarded(string text)
        {
            var expected = _forwardedText;
            if (expected == null) return false;
            _forwardedText = null;

            int frame;
            try { frame = Time.frameCount; }
            catch { return false; }
            if (frame != _forwardedFrame) return false;
            return string.Equals(expected, text, StringComparison.Ordinal);
        }

        /// <summary>绘制路径的异常单独 warning，不进熔断桶（batchmode 没有 Event，绘制失败是环境性的）。</summary>
        static void LogDrawWarning(string prefixKey, Exception ex)
        {
            bool first;
            lock (Gate) first = DrawWarnings.Add(prefixKey);
            if (!first) return;

            try
            {
                Debug.LogWarning($"[YGTextTranslator] HookHost 绘制异常（{prefixKey}，已隔离，不计入熔断）：{ex.GetType().Name}: {ex.Message}");
            }
            catch
            {
                // 日志自身异常也不能抛回 GUI。
            }
        }

        // ---------------------------------------------------------------- 记录 / 统计 / 熔断

        static bool ShouldCapture()
        {
            if (_suppressCapture) return false;

            var evt = Event.current;
            if (evt == null) return true; // batchmode / 直接调用：无 GUI 事件，探针路径照常记录

            return evt.type == EventType.Repaint || evt.type == EventType.Layout;
        }

        static void Record(string text)
        {
            bool appended;
            lock (Gate)
            {
                _hitCount++;

                if (DedupSet.Contains(text)) return;

                DedupSet.Add(text);
                // Important 4：DedupOrder 是先进先出的滑窗，窗口满了才逐出最老的文本。
                DedupOrder.Enqueue(text);
                while (DedupOrder.Count > DedupWindow)
                    DedupSet.Remove(DedupOrder.Dequeue());

                _captureCount++;
                Recent.Add(text);
                if (Recent.Count > RecentCapacity) Recent.RemoveAt(0);
                appended = true;
            }

            if (appended && ProbeMode) AppendProbeLog(text);

            var handler = OnText;
            if (handler == null) return;

            try
            {
                handler(text);
            }
            catch (Exception ex)
            {
                // 订阅者的异常不得影响 GUI，也不计入 Prefix 熔断。
                Debug.LogWarning($"[YGTextTranslator] OnText 订阅者异常（已隔离）：{ex.GetType().Name}: {ex.Message}");
            }
        }

        /// <summary>
        /// Self-review 加固：熔断记数自身（Debug.LogError / Disable / 文件 flush）绝不能把异常
        /// 抛回 Unity 的 GUI 循环。这一层是 Prefix catch 分支的最后一道隔离。
        /// </summary>
        static void SafeNoteFailure(string prefixKey, Exception ex)
        {
            try
            {
                NoteFailure(prefixKey, ex);
            }
            catch
            {
                // 已经无法可靠记日志了（LogError 自己炸），只能吞掉保住 GUI。
            }
        }

        static void NoteSuccess(string prefixKey)
        {
            lock (Gate)
            {
                // Important 1：只清自己的桶。别的 prefix 成功不能把本 prefix 的失败计数抹平。
                if (!ErrorBuckets.ContainsKey(prefixKey)) return;
                ErrorBuckets.Remove(prefixKey);
            }
        }

        static void NoteFailure(string prefixKey, Exception ex)
        {
            int count;
            lock (Gate)
            {
                _totalErrors++;
                ErrorBuckets.TryGetValue(prefixKey, out count);
                count++;
                ErrorBuckets[prefixKey] = count;
            }

            Debug.LogError($"[YGTextTranslator] HookHost Prefix 异常（{prefixKey} 连续 {count} 次）：{ex}");

            if (count >= ErrorTripThreshold && Enabled)
            {
                Debug.LogError($"[YGTextTranslator] HookHost {prefixKey} 连续 {ErrorTripThreshold} 次 Prefix 异常，自动停用钩子。");
                // Minor 6（re-review）：不在 Prefix 栈上同步 Disable —— 那会在 GUI 回调里做
                // UnpatchAll + 文件 flush。延到下一次编辑器 tick，本帧 GUI 先正常画完。
                ScheduleTrip();
            }
        }

        /// <summary>
        /// Minor 6（re-review）：熔断触发的 Disable 不在这里同步跑（那会在 GUI 回调栈上做
        /// UnpatchAll + 文件 flush），改为排到下一次编辑器 tick。同一时刻只排一次。
        /// </summary>
        static void ScheduleTrip()
        {
            if (_tripScheduled) return;
            _tripScheduled = true;
            EditorApplication.delayCall += RunDeferredTrip;
        }

        static void RunDeferredTrip()
        {
            _tripScheduled = false;
            if (!Enabled) return;
            Disable();
        }

        /// <summary>测试入口：立刻执行排队的熔断（batchmode 下 delayCall 不一定被驱动）。</summary>
        internal static void __DrainDeferredTrip()
        {
            if (_tripScheduled) RunDeferredTrip();
        }

        /// <summary>测试入口：清空熔断桶与排队中的熔断，保证连续自检不被上一轮污染。</summary>
        internal static void __TestResetErrors()
        {
            EditorApplication.delayCall -= RunDeferredTrip;
            _tripScheduled = false;
            _forwardedText = null;
            lock (Gate)
            {
                ErrorBuckets.Clear();
                _totalErrors = 0;
                DrawWarnings.Clear();
            }
        }

        // ---------------------------------------------------------------- probe.log

        static string ResolveProbeLogPath()
        {
            var dir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "YGUnityTranslator");
            Directory.CreateDirectory(dir);
            return Path.Combine(dir, "probe.log");
        }

        static void EnsureProbeLog()
        {
            if (_probeLogPath != null) return;
            try
            {
                _probeLogPath = ResolveProbeLogPath();
                _probeLogBytes = File.Exists(_probeLogPath) ? new FileInfo(_probeLogPath).Length : 0;
                File.AppendAllText(_probeLogPath, $"===== 探针会话 {DateTime.Now:yyyy-MM-dd HH:mm:ss} ====={Environment.NewLine}", Encoding.UTF8);
            }
            catch (Exception ex)
            {
                _probeLogPath = null;
                if (!_probeLogWarned)
                {
                    _probeLogWarned = true;
                    Debug.LogWarning($"[YGTextTranslator] probe.log 初始化失败（后续静默）：{ex.Message}");
                }
            }
        }

        // Important 3：patch 调用路径上禁止文件 IO。命中只把行塞进内存队列，
        // 由 Enable() 注册的 EditorApplication.update 统一排空落盘。
        static readonly StringBuilder LogBuffer = new StringBuilder();

        /// <summary>把缓冲里的探针日志落盘（Disable / update 排空时调用）。</summary>
        public static void FlushProbeLog()
        {
            string payload;
            lock (Gate)
            {
                if (LogBuffer.Length == 0) return;
                if (_probeLogPath == null || _probeLogTruncated)
                {
                    LogBuffer.Clear();
                    return;
                }

                payload = LogBuffer.ToString();
                LogBuffer.Clear();
            }

            try
            {
                // Minor 6（re-review）：GetByteCount 也可能抛，和文件写入放在同一个 try 里。
                var bytes = Encoding.UTF8.GetByteCount(payload);
                if (_probeLogBytes + bytes > ProbeLogMaxBytes)
                {
                    _probeLogTruncated = true;
                    File.AppendAllText(_probeLogPath, $"（已达 {ProbeLogMaxBytes / (1024 * 1024)} MB 上限，后续不再写入）{Environment.NewLine}", Encoding.UTF8);
                    Debug.LogWarning("[YGTextTranslator] probe.log 达到大小上限，停止写入。");
                    return;
                }

                File.AppendAllText(_probeLogPath, payload, Encoding.UTF8);
                _probeLogBytes += bytes;
            }
            catch (Exception ex)
            {
                if (!_probeLogWarned)
                {
                    _probeLogWarned = true;
                    Debug.LogWarning($"[YGTextTranslator] probe.log 写入失败（后续静默）：{ex.GetType().Name}: {ex.Message}");
                }
            }
        }

        static void AppendProbeLog(string text)
        {
            lock (Gate)
            {
                if (_probeLogPath == null || _probeLogTruncated) return;
                // 队列积压上限：硬盘卡住时宁可丢新行，也不让内存无限涨。
                if (LogBuffer.Length >= ProbeLogQueueMaxChars) return;

                LogBuffer.Append(DateTime.Now.ToString("HH:mm:ss.fff")).Append('\t').Append(text).Append(Environment.NewLine);
            }
        }

        /// <summary>Important 3：日志排空挂在 EditorApplication.update 上，不在 Prefix/Record 路径里做 IO。</summary>
        static void HookLogDrain()
        {
            if (_logDrainHooked) return;
            _logDrainHooked = true;
            EditorApplication.update -= DrainProbeLog;
            EditorApplication.update += DrainProbeLog;
        }

        /// <summary>Disable 时注销定时器（要求：Disable 停掉所有钩子/定时器）。</summary>
        static void UnhookLogDrain()
        {
            if (!_logDrainHooked) return;
            _logDrainHooked = false;
            EditorApplication.update -= DrainProbeLog;
        }

        static void DrainProbeLog()
        {
            FlushProbeLog();
        }
    }
}
