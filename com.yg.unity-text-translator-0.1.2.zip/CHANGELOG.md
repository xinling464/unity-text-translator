# 0.1.2

- 控件层补全：新增 `GUILayout.Toggle` / `Button` / `Foldout` 等 11 个绘制入口的 patch（HierarchyPlus 这类自绘控件面板之前完全没拦住）。合计 23 个 patch 点，日志会打 `PatchedCount`。
- 修掉「翻过头」：新增标识符过滤，物体名 `Body_Base`、资源名 `0Harmony.dll`、`xxx (Clone)`、无空格驼峰 `CostumeWing` 一律不翻，Hierarchy 不再显示奇怪的中文。
- 菜单汉化工具支持三种写法（`[MenuItem]` 字面量 / 完整路径常量 / 常量 + 片段拼接），VRCFury 那种 `utilities + "List All Components"` 也能改。

# 0.1.1

- 改名「团子冲击！」（包 id `com.yg.unity-text-translator` 不变，已装项目无需重装）。
- 顶部菜单新增「团子冲击！」入口：刷新翻译 / 暂停翻译 / 打开设置面板 / 打开数据目录。
- 首次启动自动启用拦截（之前需要手动跑自检才会开，属于严重缺陷）。
- 重写 README。

# 0.1.0

- 首个可用版本：运行时 IMGUI 文本替换（GUI.Label / GUI.Box / GUILayout.Label），中文字体自动挂微软雅黑。
- 在线翻译：MyMemory / 有道 / DeepL / 百度 / OpenAI 兼容，译文永久缓存，未命中异步补翻。
- 目录级汉化：补插件自带词典缺条、把写死英文的菜单改成「中文 (English)」，全部留 .ygzh.bak 可一键还原。
- 新插件入场自动扫描并按需汉化。
- 面板：在线翻译开关/后端选择/缓存统计/一键全翻译/一键还原。
