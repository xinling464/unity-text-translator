using System;
using System.Reflection;
using UnityEngine;
using UnityEngine.UIElements;

namespace YGTextTranslator
{
    /// <summary>
    /// UI Toolkit 层：Unity 2022 起很多面板（Modular Avatar、NDMF、VRChat SDK 新版界面）
    /// 走的是 UI Toolkit 而不是 IMGUI，GUI.Label 那套 patch 抓不到它们。
    /// 这里 patch <c>TextElement.text</c> 的 setter，在赋值时把英文/日文换成中文。
    /// 因为我们改的是入参而不是再调一次 setter，所以不会有重入问题。
    /// </summary>
    internal static class UiTextHook
    {
        internal static bool Patched { get; private set; }

        internal static bool TryInit()
        {
            if (Patched) return true;
            try
            {
                var prop = typeof(TextElement).GetProperty("text", BindingFlags.Public | BindingFlags.Instance);
                var setter = prop != null ? prop.GetSetMethod() : null;
                if (setter == null)
                {
                    Debug.LogWarning("[YG] UI Toolkit：找不到 TextElement.text 的 setter，跳过");
                    return false;
                }

                var prefix = typeof(UiTextHook).GetMethod(nameof(Prefix), BindingFlags.Static | BindingFlags.NonPublic);
                Patched = HarmonyLoader.Patch(setter, prefix);
                Debug.Log($"[YG] UI Toolkit 层：TextElement.text {(Patched ? "已挂上" : "挂载失败")}");
                return Patched;
            }
            catch (Exception e)
            {
                Debug.LogWarning("[YG] UI Toolkit 层初始化失败：" + e.Message);
                return false;
            }
        }

        static void Prefix(ref string value)
        {
            if (string.IsNullOrEmpty(value)) return;
            if (!HookHost.Enabled) return;

            try
            {
                if (TextPipeline.Suppress) return;
                if (!TextPipeline.ShouldTranslate(value)) return;

                var zh = TextPipeline.Translate(value);
                if (!string.IsNullOrEmpty(zh) && !ReferenceEquals(zh, value) && zh != value)
                {
                    value = zh;
                }
            }
            catch
            {
                // 绘制路径绝不能让异常冒出去
            }
        }
    }
}
