using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;

namespace YGTextTranslator
{
    /// <summary>
    /// 「以后导入的插件也自动翻」的入口。
    /// 运行时那半条腿（HookHost + TranslationApi）本来就是自动的；
    /// 这里补另外半条：项目 Packages 里一多出新插件，就自动跑一次目录级汉化
    /// （补自带词典缺条 + 改写写死英文的菜单，全部留 .ygzh.bak 可还原）。
    /// </summary>
    [InitializeOnLoad]
    internal static class PackageScanner
    {
        internal const string SnapshotName = "packages.txt";

        /// <summary>新插件入场时是否自动改盘。关掉就只在面板里提示。</summary>
        internal static bool AutoPatchNewPackages = true;

        static PackageScanner()
        {
            EditorApplication.delayCall -= FirstRun;
            EditorApplication.delayCall += FirstRun;
        }

        static string SnapshotPath => Path.Combine(CatalogPatcher.DataDir, SnapshotName);

        internal static List<string> LastNewPackages { get; private set; } = new List<string>();

        static void FirstRun()
        {
            try
            {
                var added = Scan();
                if (added.Count == 0) return;

                LastNewPackages = added;
                CatalogPatcher.Log("NEW_PACKAGES " + string.Join(",", added.ToArray()));

                if (!AutoPatchNewPackages) return;

                var r = CatalogPatcher.PatchAll();
                if (!string.IsNullOrEmpty(r.Report)) CatalogPatcher.Log("AUTO_PATCH " + r.Report);
            }
            catch (Exception e)
            {
                CatalogPatcher.Log("SCAN_ERR " + e.GetType().Name + " " + e.Message);
            }
        }

        /// <summary>比对 Packages 目录快照，返回这次新出现的包目录名。会顺手写回快照。</summary>
        internal static List<string> Scan()
        {
            var root = Path.Combine(Directory.GetCurrentDirectory(), "Packages");
            var added = new List<string>();
            if (!Directory.Exists(root)) return added;

            var dirs = Directory.GetDirectories(root);
            var current = new List<string>(dirs.Length);
            foreach (var d in dirs)
            {
                var name = Path.GetFileName(d);
                // 只关心第三方插件：Unity 官方包、VRChat SDK 都不是我们该碰的
                if (name.StartsWith("com.unity.", StringComparison.OrdinalIgnoreCase)) continue;
                if (name.StartsWith("com.vrchat.", StringComparison.OrdinalIgnoreCase)) continue;
                current.Add(name);
            }
            current.Sort(StringComparer.Ordinal);

            var before = ReadSnapshot();
            if (before.Count > 0)
            {
                foreach (var name in current)
                    if (!before.Contains(name)) added.Add(name);
            }

            WriteSnapshot(current);
            return added;
        }

        /// <summary>第一次跑（没有快照）时不该把项目里现有的插件全当成"新增"。</summary>
        static List<string> ReadSnapshot()
        {
            var list = new List<string>();
            try
            {
                if (!File.Exists(SnapshotPath)) return list;
                foreach (var line in File.ReadAllLines(SnapshotPath))
                {
                    var s = line.Trim();
                    if (s.Length > 0) list.Add(s);
                }
            }
            catch (Exception e) { CatalogPatcher.Log("SNAPSHOT_READ_ERR " + e.Message); }
            return list;
        }

        static void WriteSnapshot(List<string> current)
        {
            try
            {
                Directory.CreateDirectory(CatalogPatcher.DataDir);
                File.WriteAllText(SnapshotPath, string.Join("\n", current.ToArray()), new UTF8Encoding(false));
            }
            catch (Exception e) { CatalogPatcher.Log("SNAPSHOT_WRITE_ERR " + e.Message); }
        }
    }
}
