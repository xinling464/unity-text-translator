using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace YGTextTranslator
{
    /// <summary>
    /// 插件目录级汉化：对「自带本地化词典」的包补词条，对「菜单写死英文」的包改菜单常量。
    /// 这一层完全不碰运行时绘制，纯改磁盘文本，全部可还原（*.ygzh.bak / *.bak-ygt）。
    /// </summary>
    internal static class CatalogPatcher
    {
        internal const string BackupSuffix = ".ygzh.bak";

        // ---- MA 词典词表（en-US 有、zh-Hans 缺的那些） ----
        static readonly Dictionary<string, string> MaLexicon = new Dictionary<string, string>(StringComparer.Ordinal)
        {
            { "params.representation.Unsigned", "无符号" },
            { "params.representation.Signed", "有符号" },
            { "params.bitWidth", "{0} 位" },
            { "merge_parameter.ui.bitWidth.tooltip", "决定此参数可以表示多大的数值范围（位宽）" },
            { "merge_parameter.ui.representation.tooltip", "“有符号”参数可以表示负数值" },
            { "merge_parameter.ui.useCustomLerpDuration", "插值时长" },
            { "merge_armature.match_scale_adjusters", "匹配基础 Avatar 的 Scale Adjusters 设置" },
            { "merge_armature.match_scale_adjusters.tooltip", "当你使用 Scale Adjusters 调整过基础 Avatar 的身材比例后，勾选此项会把服装同步为与之匹配的设置。" },
            { "outfit_root.armature_root", "骨架（Armature）" },
            { "outfit_root.armature_root.tooltip", "这套服装骨架的根骨骼" },
            { "move_to.target", "目标" },
            { "move_to.match_position", "匹配位置" },
            { "move_to.match_rotation", "匹配旋转" },
            { "move_to.match_scale", "匹配缩放比例" },
            { "validation.syncparamsequence.primary_platform_changed", "[MA-0027] Sync Parameter Sequence 的主平台已变更" },
            { "validation.syncparamsequence.primary_platform_changed:description", "主平台当前设置为 {0}，但已记录的主平台构建使用的是 {1}。" },
            { "validation.syncparamsequence.primary_platform_changed:hint", "请检查同一 Avatar 不同变体上的所有 Sync Parameter Sequence 组件是否使用了相同的主平台设置。" },
            { "validation.syncparamsequence.no_primary_record", "[MA-0026] 未找到主平台参数记录" },
            { "validation.syncparamsequence.no_primary_record:description", "此 Avatar 没有保存过主平台构建的记录，但当前构建目标是 {0}、配置的主平台是 {1}。" },
            { "validation.syncparamsequence.no_primary_record:hint", "请先构建主平台变体。" },
            { "validation.legacy_vrcfury_error:hint", "使用 Reactive 组件需要 VRCFury 1.1373.0 或更高版本。请将 VRCFury 更新到最新版本。" },
            { "menuitem.default_override_warning", "此菜单项会把参数 {0} 的默认值从 {1} 改写为 {2}。\n如果不希望这样，请把 Is Default 设置改为与该参数一致，或为此菜单项手动设置零值。" },
            { "reactive_object.reactive_move.to_move", "要移动的对象" },
            { "reactive_object.reactive_move.where_to", "目标" },
            { "reactive_object.reactive_move.fix_to_world", "固定到世界坐标" },
            { "reactive_object.reactive_move.transition_time", "过渡时间" },
            { "reactive_object.reactive_move.sets_position", "设定位置" },
            { "reactive_object.reactive_move.sets_rotation", "设定旋转" },
            { "reactive_object.reactive_move.sets_scale", "设定缩放" },
            { "reactive_object.delete-mesh.uv-channel", "UV 通道" },
            { "reactive_object.delete-mesh-by-uvtile.invert", "反转" },
            { "ro_sim.effect.reactive_move.destination", "目的地：{0}" },
            { "error.parameter_assigner.value_out_of_range", "[MA-0025] 参数“{0}”的自动值过多" },
            { "error.parameter_assigner.value_out_of_range:description", "参数“{0}”的自动取值菜单项数量超过了 VRChat Int 参数的取值范围（0-255）。" },
            { "error.parameter_assigner.value_out_of_range:hint", "请减少使用此参数的自动取值菜单项，或在有效范围内为其指定明确的值。" },
            { "version_mismatch.window_title", "需要更新 Modular Avatar" },
            { "version_mismatch.headline", "你的 Modular Avatar 版本过旧" },
            { "version_mismatch.warning", "若继续操作，你的数据可能会损坏。" },
            { "version_mismatch.instructions", "请将 Modular Avatar 更新到以下版本：" },
            { "version_mismatch.required", "需要：" },
            { "version_mismatch.installed", "已安装：" },
            { "version_mismatch.affected_assets", "以下资源要求此版本：" },
            { "version_mismatch.upgrade_help", "如何升级？" },
            { "version_mismatch.refresh_asset_database", "刷新资源数据库" },
            { "version_mismatch.close_unity", "关闭 Unity" },
            { "version_mismatch.ignore", "忽略" },
            { "version_mismatch.at_your_own_risk", "（风险自负）" },
            { "version_mismatch.export_warning", "你正在从 Modular Avatar 的预发布版本导出包。这在当前稳定版本上可能导致异常行为。请务必在最新稳定版本上测试你的资源。" },
            { "version_reset.window_title", "重置版本信息" },
            { "version_reset.confirmation", "你确定要重置这些资源要求的最低版本吗？" },
            { "version_reset.current_version", "当前版本：" },
            { "version_reset.highest_required_version", "要求的最高版本：" },
            { "version_reset.none", "无" },
            { "version_reset.warning", "强制降级已有的资源可能损坏你保存的数据。重置后请检查行为是否正常。" },
            { "version_reset.set_current", "将要求的版本设为当前版本" },
            { "version_reset.clear_required_version", "清除要求的版本数据" },
            { "version_reset.cancel", "取消" },
            { "error.rename_params.bit_width_conflict", "[MA-0028] 位宽冲突" },
            { "error.rename_params.bit_width_conflict:description", "参数 {0} 指定了多个位宽：{1} != {2}" },
            { "error.rename_params.bit_width_conflict:hint", "为避免不可预期的行为，请只在一个 MA Parameters 组件里填写位宽，其余留空。若存在多个值，Modular Avatar 会按层级顺序采用第一个指定的位宽。" },
            { "error.rename_params.representation_conflict", "[MA-0029] 表示法冲突" },
            { "error.rename_params.representation_conflict:description", "参数 {0} 指定了多个表示法：{1} != {2}" },
            { "error.rename_params.representation_conflict:hint", "为避免不可预期的行为，请只在一个 MA Parameters 组件里填写表示法，其余留空。若存在多个值，Modular Avatar 会按层级顺序采用第一个指定的表示法。" },
            { "error.rename_params.lerp_duration_conflict", "[MA-0030] 插值时长冲突" },
            { "error.rename_params.lerp_duration_conflict:description", "参数 {0} 指定了多个插值时长：{1} != {2}" },
            { "error.rename_params.lerp_duration_conflict:hint", "为避免不可预期的行为，请只在一个 MA Parameters 组件里填写插值时长，其余留空。若存在多个值，Modular Avatar 会按层级顺序采用第一个指定的插值时长。" },
            { "error.rename_collision_tags.ambiguous_parameter", "[MA-0031] 碰撞标签参数名有歧义" },
            { "error.rename_collision_tags.ambiguous_parameter:description", "参数 {0} 中包含两个或更多 `_CollisionTag_`。" },
            { "error.rename_collision_tags.ambiguous_parameter:hint", "请从前缀或标签中移除字面量 `_CollisionTag_`。" },
        };

        // ---- 菜单常量词表：英文路径 -> 中文（英文括注保留，方便对照教程） ----
        static readonly (string en, string zh)[] MenuItems = new[]
        {
            ("GameObject/Modular Avatar/Setup Outfit", "GameObject/Modular Avatar/设置服装 (Setup Outfit)"),
            ("GameObject/Modular Avatar/Create Toggle", "GameObject/Modular Avatar/创建开关 (Create Toggle)"),
            ("GameObject/Modular Avatar/Create Toggle for Selection", "GameObject/Modular Avatar/为所选对象创建开关 (Create Toggle for Selection)"),
            ("GameObject/Modular Avatar/Manual Bake Avatar", "GameObject/Modular Avatar/手动烘焙 Avatar (Manual Bake Avatar)"),
            ("GameObject/Modular Avatar/Show Modular Avatar Information", "GameObject/Modular Avatar/显示 MA 信息 (Show Modular Avatar Information)"),
            ("GameObject/Modular Avatar/Show Reaction Debugger", "GameObject/Modular Avatar/显示反应调试器 (Show Reaction Debugger)"),
            ("GameObject/Modular Avatar/Dump RC Blend Tree", "GameObject/Modular Avatar/导出 RC 混合树 (Dump RC Blend Tree)"),
            ("GameObject/Modular Avatar/Show Fit Preview", "GameObject/Modular Avatar/预览适配效果 (Show Fit Preview)"),
            ("GameObject/Modular Avatar/Extract Menu", "GameObject/Modular Avatar/提取菜单 (Extract Menu)"),
            ("GameObject/Modular Avatar/Reset version information", "GameObject/Modular Avatar/重置版本信息 (Reset version information)"),
            ("Tools/Modular Avatar/Sync Bones in Edit Mode", "Tools/Modular Avatar/编辑模式同步骨骼 (Sync Bones in Edit Mode)"),
            ("Tools/Modular Avatar/Show Modular Avatar Information", "Tools/Modular Avatar/显示 MA 信息 (Show Modular Avatar Information)"),
            ("Tools/Modular Avatar/Manual Bake Avatar", "Tools/Modular Avatar/手动烘焙 Avatar (Manual Bake Avatar)"),
            ("Tools/Modular Avatar/Manual bake avatar", "Tools/Modular Avatar/手动烘焙 Avatar (Manual bake avatar)"),
            ("Tools/Modular Avatar/Reload Localizations", "Tools/Modular Avatar/重新加载本地化 (Reload Localizations)"),
            ("Tools/Modular Avatar/Debug/Log Sync Parameter Sequence", "Tools/Modular Avatar/调试/记录同步参数序列 (Log Sync Parameter Sequence)"),
            ("Tools/Modular Avatar/Debug/Show Version Mismatch Warning", "Tools/Modular Avatar/调试/显示版本不匹配警告 (Show Version Mismatch Warning)"),
            ("Tools/Modular Avatar/Debug/Show Version Mismatch Warning (Non-Modal)", "Tools/Modular Avatar/调试/显示版本不匹配警告（非模态）(Non-Modal)"),
        };

        internal struct Result
        {
            internal int LexiconAdded;
            internal int MenuChanged;
            internal List<string> PackagesTouched;
            internal string Report;
        }

        internal static string DataDir => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "YGUnityTranslator");

        static string PackagesRoot => Path.Combine(Directory.GetCurrentDirectory(), "Packages");

        // ============ 主入口 ============

        internal static Result PatchAll()
        {
            var res = new Result { PackagesTouched = new List<string>(), Report = "" };
            foreach (var pkgDir in SafeDirs(PackagesRoot))
            {
                var name = Path.GetFileName(pkgDir);
                if (name.StartsWith("com.unity.") || name.StartsWith("com.vrchat.")) continue;

                if (name == "nadena.dev.modular-avatar")
                {
                    res.LexiconAdded += PatchLexicon(pkgDir, "Editor/Localization", "zh-Hans.json", "en-US.json", MaLexicon);
                    res.MenuChanged += PatchMenus(pkgDir);
                    if (res.LexiconAdded > 0 || res.MenuChanged > 0) res.PackagesTouched.Add(name);
                }
                else
                {
                    // 通用：任何沿用 NDMF 风格 Localization 目录的包，只处理本地已有词表能覆盖的键
                    var loc = Path.Combine(pkgDir, "Editor", "Localization");
                    if (Directory.Exists(loc))
                    {
                        var n = PatchLexicon(pkgDir, "Editor/Localization", "zh-Hans.json", "en-US.json", MaLexicon);
                        if (n > 0) { res.LexiconAdded += n; res.PackagesTouched.Add(name); }
                    }
                }
            }

            res.Report = $"词典新增 {res.LexiconAdded} 条，菜单改 {res.MenuChanged} 处，涉及 {res.PackagesTouched.Count} 个包";
            if (res.LexiconAdded > 0 || res.MenuChanged > 0) AssetDatabase.Refresh();
            Log("PATCH  " + res.Report);
            return res;
        }

        // ============ 词典 ============

        static int PatchLexicon(string pkgDir, string relDir, string zhFile, string enFile, Dictionary<string, string> lexicon)
        {
            var dir = Path.Combine(pkgDir, relDir.Replace('/', Path.DirectorySeparatorChar));
            var zhPath = Path.Combine(dir, zhFile);
            var enPath = Path.Combine(dir, enFile);
            if (!File.Exists(zhPath) || !File.Exists(enPath)) return 0;

            var zh = FlatJson.Parse(File.ReadAllText(zhPath));
            var en = FlatJson.Parse(File.ReadAllText(enPath));
            if (zh == null || en == null) return 0;

            int added = 0;
            foreach (var kv in lexicon)
            {
                if (en.ContainsKey(kv.Key) && !zh.ContainsKey(kv.Key))
                {
                    zh[kv.Key] = kv.Value;
                    added++;
                }
            }
            if (added == 0) return 0;

            var bak = zhPath + BackupSuffix;
            if (!File.Exists(bak)) File.Copy(zhPath, bak);
            File.WriteAllText(zhPath, FlatJson.Serialize(zh), new UTF8Encoding(true));
            Log($"LEXICON {Path.GetFileName(pkgDir)} +{added}");
            return added;
        }

        // ============ 菜单 ============

        static int PatchMenus(string pkgDir)
        {
            int changed = 0;
            foreach (var cs in SafeFiles(pkgDir, "*.cs"))
            {
                var src = File.ReadAllText(cs);
                var patched = src;
                foreach (var (en, zh) in MenuItems)
                {
                    var needle = "\"" + en + "\"";
                    if (patched.Contains(needle)) patched = patched.Replace(needle, "\"" + zh + "\"");
                }
                if (patched == src) continue;

                var bak = cs + BackupSuffix;
                if (!File.Exists(bak)) File.Copy(cs, bak);
                File.WriteAllText(cs, patched, new UTF8Encoding(false));
                changed++;
            }
            if (changed > 0) Log($"MENU {Path.GetFileName(pkgDir)} {changed} 个文件");
            return changed;
        }

        // ============ 还原 ============

        internal static int RestoreAll()
        {
            int n = 0;
            foreach (var f in SafeFiles(PackagesRoot, "*" + BackupSuffix, true))
            {
                if (f.EndsWith(".bak")) continue;
                var orig = f.Substring(0, f.Length - BackupSuffix.Length);
                File.Copy(f, orig, true);
                n++;
            }
            if (n > 0) AssetDatabase.Refresh();
            Log("RESTORE " + n + " 个文件");
            return n;
        }

        // ============ 工具 ============

        static IEnumerable<string> SafeDirs(string root)
        {
            if (!Directory.Exists(root)) yield break;
            foreach (var d in Directory.GetDirectories(root)) yield return d;
        }

        static IEnumerable<string> SafeFiles(string root, string pattern, bool nested = false)
        {
            if (!Directory.Exists(root)) yield break;
            var opt = nested ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;
            string[] files;
            try { files = Directory.GetFiles(root, pattern, opt); }
            catch { yield break; }
            foreach (var f in files) yield return f;
        }

        internal static void Log(string line)
        {
            try
            {
                var dir = DataDir;
                Directory.CreateDirectory(dir);
                File.AppendAllText(Path.Combine(dir, "catalog-patch.log"),
                    DateTime.Now.ToString("HH:mm:ss.fff") + "\t" + line + Environment.NewLine, new UTF8Encoding(false));
            }
            catch { /* 日志失败不影响主流程 */ }
        }

        /// <summary>MA 的词典是平铺的 string->string JSON，这里只做这一种，够用且不会误伤嵌套结构。</summary>
        internal static class FlatJson
        {
            internal static Dictionary<string, string> Parse(string text)
            {
                if (string.IsNullOrEmpty(text)) return null;
                var map = new Dictionary<string, string>(StringComparer.Ordinal);
                int i = 0;
                if (text.Length > 0 && text[0] == '\uFEFF') i = 1;
                SkipWs(text, ref i);
                if (i >= text.Length || text[i] != '{') return null;
                i++;
                while (i < text.Length)
                {
                    SkipWs(text, ref i);
                    if (i < text.Length && text[i] == '}') return map;
                    if (i >= text.Length || text[i] != '"') return null;
                    var key = ReadString(text, ref i);
                    SkipWs(text, ref i);
                    if (i >= text.Length || text[i] != ':') return null;
                    i++;
                    SkipWs(text, ref i);
                    if (i >= text.Length || text[i] != '"') return null;
                    var val = ReadString(text, ref i);
                    map[key] = val;
                    SkipWs(text, ref i);
                    if (i < text.Length && text[i] == ',') { i++; continue; }
                    if (i < text.Length && text[i] == '}') return map;
                    return null;
                }
                return map;
            }

            internal static string Serialize(Dictionary<string, string> map)
            {
                var sb = new StringBuilder();
                sb.Append("{\n");
                int n = 0;
                foreach (var kv in map)
                {
                    sb.Append("  \"").Append(Escape(kv.Key)).Append("\": \"").Append(Escape(kv.Value)).Append('"');
                    sb.Append(++n < map.Count ? ",\n" : "\n");
                }
                sb.Append('}');
                return sb.ToString();
            }

            static void SkipWs(string s, ref int i)
            {
                while (i < s.Length && (s[i] == ' ' || s[i] == '\t' || s[i] == '\r' || s[i] == '\n')) i++;
            }

            static string ReadString(string s, ref int i)
            {
                i++; // 跳过起始引号
                var sb = new StringBuilder();
                while (i < s.Length)
                {
                    var c = s[i++];
                    if (c == '"') return sb.ToString();
                    if (c != '\\') { sb.Append(c); continue; }
                    if (i >= s.Length) break;
                    var e = s[i++];
                    switch (e)
                    {
                        case 'n': sb.Append('\n'); break;
                        case 't': sb.Append('\t'); break;
                        case 'r': sb.Append('\r'); break;
                        case 'b': sb.Append('\b'); break;
                        case 'f': sb.Append('\f'); break;
                        case '"': sb.Append('"'); break;
                        case '\\': sb.Append('\\'); break;
                        case '/': sb.Append('/'); break;
                        case 'u':
                            if (i + 4 <= s.Length &&
                                ushort.TryParse(s.Substring(i, 4), System.Globalization.NumberStyles.HexNumber, null, out var code))
                            {
                                sb.Append((char)code);
                                i += 4;
                            }
                            break;
                        default: sb.Append(e); break;
                    }
                }
                return sb.ToString();
            }

            static string Escape(string s)
            {
                var sb = new StringBuilder(s.Length + 8);
                foreach (var c in s)
                {
                    switch (c)
                    {
                        case '"': sb.Append("\\\""); break;
                        case '\\': sb.Append("\\\\"); break;
                        case '\n': sb.Append("\\n"); break;
                        case '\r': sb.Append("\\r"); break;
                        case '\t': sb.Append("\\t"); break;
                        default: sb.Append(c); break;
                    }
                }
                return sb.ToString();
            }
        }
    }
}
