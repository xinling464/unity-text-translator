using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using UnityEditor;
using UnityEngine;

namespace YGTextTranslator
{
    /// <summary>
    /// 在线翻译后端 + 本地缓存。
    /// 设计要点：
    ///  1. 主线程永不等待网络：Lookup 命中缓存就返回译文，miss 立刻返回 null 并丢进后台队列。
    ///  2. 同一条文本只请求一次，结果永久落盘（cache.json），断网也能继续用。
    ///  3. 默认后端 MyMemory（免费、无需 key、本机实测可达），可切成有道 / DeepL / 百度 / OpenAI 兼容。
    /// </summary>
    internal static class TranslationApi
    {
        internal enum Backend { MyMemory, Youdao, Deepl, Baidu, OpenAICompat }

        static readonly HttpClient Http = new HttpClient { Timeout = TimeSpan.FromSeconds(15) };
        static readonly ConcurrentQueue<string> ReqQueue = new ConcurrentQueue<string>();
        static readonly List<KeyValuePair<string, string>> Pending = new List<KeyValuePair<string, string>>();
        static readonly object PendingLock = new object();
        static readonly Dictionary<string, string> Cache = new Dictionary<string, string>(StringComparer.Ordinal);
        static readonly HashSet<string> Failed = new HashSet<string>(StringComparer.Ordinal);
        static readonly HashSet<string> Queued = new HashSet<string>(StringComparer.Ordinal);
        static readonly object QueuedLock = new object();

        static bool _loaded;
        static bool _workerRunning;
        static volatile bool _enabled = true;
        static int _inFlight;
        static DateTime _lastRequest = DateTime.MinValue;

        // 你在面板里能改的配置
        internal static Backend CurrentBackend = Backend.MyMemory;
        internal static string ApiKey = "";        // DeepL / 百度 / OpenAI 用
        internal static string ApiSecret = "";     // 百度用
        internal static string ApiEndpoint = "";   // OpenAI 兼容用（如 http://127.0.0.1:11434/v1/chat/completions）

        internal static bool Enabled
        {
            get => _enabled;
            set => _enabled = value;
        }

        internal static int CachedCount { get { EnsureLoaded(); return Cache.Count; } }
        internal static int QueuedCount => ReqQueue.Count;
        internal static int FailedCount { get { EnsureLoaded(); return Failed.Count; } }

        static string CachePath => Path.Combine(CatalogPatcher.DataDir, "cache.json");

        // ============ 对外：主线程调用 ============

        /// <summary>命中返回译文；未命中返回 null，并在后台排队翻译（下次绘制就有中文）。</summary>
        internal static string Lookup(string text, string srcLang)
        {
            if (string.IsNullOrEmpty(text) || !_enabled) return null;
            EnsureLoaded();

            var key = srcLang + "|" + text;
            if (Cache.TryGetValue(key, out var zh)) return zh;
            if (Failed.Contains(key)) return null;

            // 绘制是每帧多次调用的：同一条未命中文本只入队一次，否则队列秒爆。
            lock (QueuedLock)
            {
                if (!Queued.Add(key)) return null;
            }

            if (ReqQueue.Count < 4000) ReqQueue.Enqueue(key);
            StartWorker();
            return null;
        }

        /// <summary>主线程里调用，把后台完成的结果搬进缓存并落盘。</summary>
        internal static int Drain()
        {
            if (!_workerRunning && _inFlight == 0 && ReqQueue.IsEmpty) { } // 仍在跑也允许 drain

            List<KeyValuePair<string, string>> done;
            lock (PendingLock)
            {
                if (Pending.Count == 0) return 0;
                done = new List<KeyValuePair<string, string>>(Pending);
                Pending.Clear();
            }

            EnsureLoaded();
            foreach (var kv in done)
            {
                lock (QueuedLock) Queued.Remove(kv.Key);
                if (string.IsNullOrEmpty(kv.Value)) Failed.Add(kv.Key);
                else Cache[kv.Key] = kv.Value;
            }
            Save();
            return done.Count;
        }

        internal static void ClearCache()
        {
            Cache.Clear();
            Failed.Clear();
            Save();
            CatalogPatcher.Log("CACHE cleared");
        }

        // ============ 后台 ============

        static void StartWorker()
        {
            if (_workerRunning) return;
            _workerRunning = true;
            Task.Run(async () =>
            {
                try
                {
                    while (true)
                    {
                        if (!ReqQueue.TryDequeue(out var key))
                        {
                            await Task.Delay(400).ConfigureAwait(false);
                            if (ReqQueue.IsEmpty) break;   // 队列空了就退出，下次有需要再启
                            continue;
                        }

                        // 限速：后端都是免费的，太快会被掐
                        var gap = DateTime.UtcNow - _lastRequest;
                        if (gap.TotalMilliseconds < 350) await Task.Delay(350 - (int)gap.TotalMilliseconds).ConfigureAwait(false);

                        var idx = key.IndexOf('|');
                        if (idx <= 0) continue;
                        var lang = key.Substring(0, idx);
                        var text = key.Substring(idx + 1);
                        if (text.Length > 900) { lock (PendingLock) Pending.Add(new KeyValuePair<string, string>(key, "")); continue; }

                        string zh = null;
                        try
                        {
                            Interlocked.Increment(ref _inFlight);
                            _lastRequest = DateTime.UtcNow;
                            zh = await TranslateOnce(text, lang).ConfigureAwait(false);
                        }
                        catch (Exception e)
                        {
                            CatalogPatcher.Log("API_ERR " + e.GetType().Name + " " + e.Message);
                        }
                        finally { Interlocked.Decrement(ref _inFlight); }

                        lock (PendingLock) Pending.Add(new KeyValuePair<string, string>(key, zh));
                    }
                }
                finally { _workerRunning = false; }
            });
        }

        static async Task<string> TranslateOnce(string text, string srcLang)
        {
            switch (CurrentBackend)
            {
                case Backend.Youdao: return await Youdao(text, srcLang).ConfigureAwait(false);
                case Backend.Deepl: return await Deepl(text, srcLang).ConfigureAwait(false);
                case Backend.Baidu: return await Baidu(text, srcLang).ConfigureAwait(false);
                case Backend.OpenAICompat: return await OpenAi(text, srcLang).ConfigureAwait(false);
                default: return await MyMemory(text, srcLang).ConfigureAwait(false);
            }
        }

        // ============ 各家后端 ============

        static string Code(string lang) => lang == "ja" ? "ja" : "en";

        static async Task<string> MyMemory(string text, string srcLang)
        {
            var url = "https://api.mymemory.translated.net/get?q=" + Uri.EscapeDataString(text) +
                      "&langpair=" + Code(srcLang) + "|zh-CN";
            var body = await Http.GetStringAsync(url).ConfigureAwait(false);
            var i = body.IndexOf("\"translatedText\":\"", StringComparison.Ordinal);
            if (i < 0) return null;
            i += "\"translatedText\":\"".Length;
            var s = ReadJsonString(body, ref i).Trim();
            // MyMemory 查不到时会原样回英文，或者回一句 "QUERY LENGTH LIMIT"
            if (string.IsNullOrEmpty(s) || s.IndexOf("QUERY LENGTH", StringComparison.OrdinalIgnoreCase) >= 0) return null;
            if (s.Trim().ToLowerInvariant() == text.Trim().ToLowerInvariant()) return null;
            return s;
        }

        static async Task<string> Youdao(string text, string srcLang)
        {
            var url = "https://aidemo.youdao.com/trans?q=" + Uri.EscapeDataString(text) +
                      "&from=" + Code(srcLang) + "&to=zh-CHS";
            var body = await Http.GetStringAsync(url).ConfigureAwait(false);
            // 结构：{"translation":["启用"], ...}
            var i = body.IndexOf("\"translation\":[", StringComparison.Ordinal);
            if (i < 0) return null;
            i = body.IndexOf('"', i + "\"translation\":[".Length);
            if (i < 0) return null;
            i++;
            return ReadJsonString(body, ref i).Trim();
        }

        static async Task<string> Deepl(string text, string srcLang)
        {
            if (string.IsNullOrEmpty(ApiKey)) return null;
            var url = "https://api-free.deepl.com/v2/translate?auth_key=" + Uri.EscapeDataString(ApiKey) +
                      "&text=" + Uri.EscapeDataString(text) + "&source_lang=" + Code(srcLang).ToUpperInvariant() + "&target_lang=ZH";
            var body = await Http.GetStringAsync(url).ConfigureAwait(false);
            var i = body.IndexOf("\"text\":\"", StringComparison.Ordinal);
            if (i < 0) return null;
            i += "\"text\":\"".Length;
            var end = body.IndexOf('"', i);
            return end > i ? body.Substring(i, end - i) : null;
        }

        static async Task<string> Baidu(string text, string srcLang)
        {
            if (string.IsNullOrEmpty(ApiKey) || string.IsNullOrEmpty(ApiSecret)) return null;
            var salt = DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString();
            var sign = Md5(ApiKey + text + salt + ApiSecret);
            var url = "https://fanyi-api.baidu.com/api/trans/vip/translate?q=" + Uri.EscapeDataString(text) +
                      "&from=" + Code(srcLang) + "&to=zh&appid=" + ApiKey + "&salt=" + salt + "&sign=" + sign;
            var body = await Http.GetStringAsync(url).ConfigureAwait(false);
            var i = body.IndexOf("\"dst\":\"", StringComparison.Ordinal);
            if (i < 0) return null;
            i += "\"dst\":\"".Length;
            var end = body.IndexOf('"', i);
            return end > i ? body.Substring(i, end - i) : null;
        }

        static async Task<string> OpenAi(string text, string srcLang)
        {
            if (string.IsNullOrEmpty(ApiEndpoint)) return null;
            var payload = "{\"model\":\"" + "gpt-4o-mini" + "\",\"messages\":[{\"role\":\"system\",\"content\":\"" +
                          "你是 Unity 插件界面汉化译者。只输出译文，不要解释，专有名词保留英文。" +
                          "\"},{\"role\":\"user\",\"content\":\"" + JsonEscape(text) + "\"}],\"temperature\":0}";
            using (var content = new StringContent(payload, Encoding.UTF8, "application/json"))
            {
                if (!string.IsNullOrEmpty(ApiKey))
                    Http.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", "Bearer " + ApiKey);
                var resp = await Http.PostAsync(ApiEndpoint, content).ConfigureAwait(false);
                var body = await resp.Content.ReadAsStringAsync().ConfigureAwait(false);
                var i = body.IndexOf("\"content\":\"", StringComparison.Ordinal);
                if (i < 0) return null;
                i += "\"content\":\"".Length;
                return ReadJsonString(body, ref i).Trim();
            }
        }

        // ============ 工具 ============
        /// <summary>
        /// 从 JSON 字符串正文起始位置读到闭合引号，处理 \\、\"、\n、\t 和 \uXXXX。
        /// MyMemory 对中文常回 uXXXX 转义形式，不还原就会把 u542fu7528 直接显示出来。
        /// </summary>
        static string ReadJsonString(string body, ref int i)
        {
            var sb = new StringBuilder();
            while (i < body.Length)
            {
                var c = body[i];
                if (c == '\\' && i + 1 < body.Length)
                {
                    var n = body[i + 1];
                    if ((n == 'u' || n == 'U') && i + 5 < body.Length)
                    {
                        int code;
                        if (int.TryParse(body.Substring(i + 2, 4), System.Globalization.NumberStyles.HexNumber,
                                          System.Globalization.CultureInfo.InvariantCulture, out code))
                        {
                            sb.Append((char)code);
                            i += 6;
                            continue;
                        }
                    }

                    sb.Append(Unescape(n));
                    i += 2;
                    continue;
                }

                if (c == '"') { i++; break; }
                sb.Append(c);
                i++;
            }

            return sb.ToString();
        }

        static char Unescape(char c)
        {
            switch (c)
            {
                case 'n': return '\n';
                case 't': return '\t';
                case 'r': return '\r';
                default: return c;
            }
        }

        static string JsonEscape(string s) => s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n");

        static string Md5(string s)
        {
            using (var md5 = System.Security.Cryptography.MD5.Create())
            {
                var bytes = md5.ComputeHash(Encoding.UTF8.GetBytes(s));
                var sb = new StringBuilder();
                foreach (var b in bytes) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        static void EnsureLoaded()
        {
            if (_loaded) return;
            _loaded = true;
            try
            {
                if (!File.Exists(CachePath)) return;
                var map = CatalogPatcher.FlatJson.Parse(File.ReadAllText(CachePath));
                if (map == null) return;
                foreach (var kv in map) Cache[kv.Key] = kv.Value;
            }
            catch (Exception e) { CatalogPatcher.Log("CACHE_LOAD_ERR " + e.Message); }
        }

        static void Save()
        {
            try
            {
                Directory.CreateDirectory(CatalogPatcher.DataDir);
                var map = new Dictionary<string, string>(StringComparer.Ordinal);
                foreach (var kv in Cache) map[kv.Key] = kv.Value;
                File.WriteAllText(CachePath, CatalogPatcher.FlatJson.Serialize(map), new UTF8Encoding(false));
            }
            catch (Exception e) { CatalogPatcher.Log("CACHE_SAVE_ERR " + e.Message); }
        }
    }
}
