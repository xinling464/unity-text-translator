using UnityEditor;
using UnityEditorInternal;
using UnityEngine;

namespace YGTextTranslator
{
    /// <summary>
    /// 顶部菜单栏的快捷入口。
    /// Unity 顶部菜单是原生 C++ 菜单（拦不到、也不会被翻译），
    /// 所以这里直接挂一个顶层菜单，点一次就刷新当前界面。
    /// </summary>
    internal static class QuickMenu
    {
        private const string Root = "团子冲击！";

        [MenuItem(Root + "/刷新翻译", false, 1)]
        private static void RefreshNow()
        {
            // 没启用就先启用（比如刚重编译过、Hook 被卸载了）
            if (!HookHost.Enabled)
            {
                Bootstrap.TryEnable(false);
            }

            // 清掉内存缓存并按需重排：miss 的词条会重新排队送去在线翻译
            TextPipeline.Reload();
            InternalEditorUtility.RepaintAllViews();

            Debug.Log("[YG] 已刷新：patched=" + HookHost.PatchedCount + "，待译词条重新排队，几秒后即可看到中文");
        }

        [MenuItem(Root + "/暂停翻译", false, 2)]
        private static void Pause()
        {
            if (!HookHost.Enabled)
            {
                Debug.Log("[YG] 翻译本来就是关着的");
                return;
            }

            HookHost.Disable();
            InternalEditorUtility.RepaintAllViews();
            Debug.Log("[YG] 翻译已暂停（点「YG 翻译/刷新翻译」即可恢复）");
        }

        [MenuItem(Root + "/打开设置面板…", false, 21)]
        private static void OpenSettings()
        {
            EditorWindow.GetWindow<TranslatorWindow>("插件文本翻译");
        }

        [MenuItem(Root + "/打开数据目录", false, 40)]
        private static void OpenDataDir()
        {
            EditorUtility.RevealInFinder(CatalogPatcher.DataDir);
        }
    }
}
