using UnityEditor;

namespace YGTextTranslator
{
    /// <summary>
    /// 在线翻译驱动。职责很窄：把后台线程翻好的结果搬进缓存，然后让界面重画一次。
    /// 必须用 InitializeOnLoad 抢在所有 Hook 之前装好，否则第一批未命中文本没人收。
    /// </summary>
    [InitializeOnLoad]
    internal static class OnlineTranslator
    {
        static OnlineTranslator()
        {
            EditorApplication.update -= Tick;
            EditorApplication.update += Tick;
        }

        static int _drainedTotal;

        internal static int DrainedTotal => _drainedTotal;

        static void Tick()
        {
            if (!TranslationApi.Enabled) return;

            var n = TranslationApi.Drain();
            if (n <= 0) return;

            _drainedTotal += n;

            // 新译文进缓存了：丢掉 TextPipeline 的句柄缓存（里面可能存着"未命中=原文"的旧结论），
            // 再让所有视图重画一遍，用户下一眼就是中文。
            TextPipeline.ClearCache();
            UnityEditorInternal.InternalEditorUtility.RepaintAllViews();
        }
    }
}
