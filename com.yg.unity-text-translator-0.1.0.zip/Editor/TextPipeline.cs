﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using UnityEditor.PackageManager;
using UnityEngine;

namespace YGTextTranslator
{
    /// <summary>
    /// 文本判定与翻译的唯一入口（R2 的接缝）。Task 4 先用内置词典实现，
    /// Task 5 会把内部替换为 Lexicon.TryGet + Collector.Note，外部签名保持不变。
    ///
    /// 约束：patch 调用路径上不做任何 IO。词典只在第一次 EnsureLoaded 时读盘，
    /// 之后 Translate 只查内存 + 按文本 hash 缓存（R16）。
    /// </summary>
    internal static class TextPipeline
    {
        const string BuiltinRelativePath = "lexicons/builtin.json";
        const int CacheCapacity = 8192;

        static readonly object Gate = new object();
        static readonly Dictionary<string, string> Builtin = new Dictionary<string, string>(StringComparer.Ordinal);

        // R16：按文本 hash 缓存，值只存翻译结果；CacheSource 用原文做碰撞校验。
        static readonly Dictionary<int, string> Cache = new Dictionary<int, string>();
        static readonly Dictionary<int, string> CacheSource = new Dictionary<int, string>();

        static bool _loadAttempted;
        static bool _loaded;
        static string _loadError;
        static int _hitCount;
        static int _missCount;

        /// <summary>重入抑制：替换路径自己调 GUI.Label 时置位，避免再次进入 prefix。</summary>
        public static bool Suppress { get; set; }

        public static int HitCount { get { return Volatile.Read(ref _hitCount); } }
        public static int MissCount { get { return Volatile.Read(ref _missCount); } }

        public static int EntryCount
        {
            get
            {
                EnsureLoaded();
                lock (Gate) return Builtin.Count;
            }
        }

        public static bool IsLoaded
        {
            get
            {
                EnsureLoaded();
                return _loaded;
            }
        }

        public static string LoadError
        {
            get
            {
                EnsureLoaded();
                return _loadError;
            }
        }

        internal static void EnsureLoaded()
        {
            if (_loadAttempted) return;

            lock (Gate)
            {
                if (_loadAttempted) return;
                _loadAttempted = true;

                try
                {
                    var path = ResolveBuiltinPath();
                    if (string.IsNullOrEmpty(path))
                    {
                        _loadError = "package root not found";
                    }
                    else if (!File.Exists(path))
                    {
                        _loadError = "file not found: " + path;
                    }
                    else
                    {
                        var json = File.ReadAllText(path, Encoding.UTF8);
                        Dictionary<string, string> parsed;
                        string parseError;
                        if (!BuiltinJson.TryParseEntries(json, out parsed, out parseError))
                        {
                            _loadError = parseError;
                        }
                        else if (parsed.Count == 0)
                        {
                            _loadError = "no entries";
                        }
                        else
                        {
                            foreach (var kv in parsed) Builtin[kv.Key] = kv.Value;
                            _loaded = true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    _loadError = ex.GetType().Name + ": " + ex.Message;
                }
            }

            if (!_loaded)
                Debug.LogWarning($"[YGTextTranslator] builtin.json 加载失败：{_loadError}");
        }

        static string ResolveBuiltinPath()
        {
            var info = PackageInfo.FindForAssembly(typeof(TextPipeline).Assembly);
            if (info == null || string.IsNullOrEmpty(info.resolvedPath)) return null;
            return Path.Combine(info.resolvedPath, BuiltinRelativePath);
        }

        /// <summary>
        /// 判定表（与 brief 一致）：
        /// - null/空/全空白/纯数字与符号 → false
        /// - 含 CJK（含日文汉字，歧义） → false，中文 UI 原样放行
        /// - 含假名（かな/カナ） → true，即使同时含汉字
        /// - 有 ASCII 字母且无 CJK → true
        /// </summary>
        public static bool ShouldTranslate(string text)
        {
            if (string.IsNullOrEmpty(text)) return false;

            var hasAsciiLetter = false;
            var hasCjk = false;
            var hasKana = false;

            for (var i = 0; i < text.Length; i++)
            {
                var c = text[i];
                if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'))
                {
                    hasAsciiLetter = true;
                    continue;
                }

                if ((c >= '\u4E00' && c <= '\u9FFF') || (c >= '\u3400' && c <= '\u4DBF'))
                {
                    hasCjk = true;
                    continue;
                }

                if (c >= '\u3040' && c <= '\u30FF') hasKana = true;
            }

            // 假名优先：影の強さ / オン・オフ 这类日文即使含汉字也要翻；纯汉字歧义才跳过。
            if (hasKana) return true;
            if (hasCjk) return false;
            return hasAsciiLetter;
        }

        /// <summary>给在线翻译用：有假名按日文，否则按英文。</summary>
        public static string DetectLang(string text)
        {
            if (string.IsNullOrEmpty(text)) return "en";
            for (var i = 0; i < text.Length; i++)
            {
                var c = text[i];
                if (c >= '\u3040' && c <= '\u30FF') return "ja";
            }
            return "en";
        }

        /// <summary>
        /// 命中词典返回中文；未命中/空/null 原样返回（绝不返回 null 或空串替换原文）。
        /// 这是 Task 5 Lexicon 的唯一接缝。
        /// </summary>
        public static string Translate(string text)
        {
            if (string.IsNullOrEmpty(text)) return text;

            EnsureLoaded();

            var hash = text.GetHashCode();
            string cached;
            lock (Gate)
            {
                if (Cache.TryGetValue(hash, out cached))
                {
                    string source;
                    if (CacheSource.TryGetValue(hash, out source) && string.Equals(source, text, StringComparison.Ordinal))
                    {
                        if (string.Equals(cached, text, StringComparison.Ordinal)) Interlocked.Increment(ref _missCount);
                        else Interlocked.Increment(ref _hitCount);
                        return cached;
                    }
                }
            }

            string result;
            bool hit;
            lock (Gate)
            {
                hit = Builtin.TryGetValue(text, out result);
            }

            if (!hit)
            {
                // 在线翻译（异步）：命中缓存立刻用；未命中入队，本次仍显示原文，下次绘制就是中文
                var online = TranslationApi.Lookup(text, DetectLang(text));
                if (!string.IsNullOrEmpty(online))
                {
                    result = online;
                    hit = true;
                }
            }

            if (hit)
            {
                Interlocked.Increment(ref _hitCount);
                lock (Gate)
                {
                    if (Cache.Count >= CacheCapacity)
                    {
                        Cache.Clear();
                        CacheSource.Clear();
                    }

                    Cache[hash] = result;
                    CacheSource[hash] = text;
                }

                return result;
            }

            // 未命中：**不缓存原文**，否则在线译文回来后永远轮不到它。等 Drain 完自然命中。
            Interlocked.Increment(ref _missCount);
            return text;
        }

        /// <summary>Task 5 热加载词典后调用，丢掉旧的翻译缓存。</summary>
        internal static void ClearCache()
        {
            lock (Gate)
            {
                Cache.Clear();
                CacheSource.Clear();
            }
        }

        /// <summary>T5/T6：重新读 builtin.json，复位加载失败状态并清空翻译缓存。</summary>
        public static void Reload()
        {
            lock (Gate)
            {
                _loadAttempted = false;
                _loaded = false;
                _loadError = null;
                Builtin.Clear();
                Cache.Clear();
                CacheSource.Clear();
            }

            EnsureLoaded();
        }

        /// <summary>测试入口：解析任意 builtin JSON，返回指定 key 的值与条目数；不碰全局词典。</summary>
        internal static bool __TestParseBuiltin(string json, string key, out string value, out int count, out string error)
        {
            value = null;
            count = 0;
            Dictionary<string, string> parsed;
            if (!BuiltinJson.TryParseEntries(json, out parsed, out error)) return false;
            count = parsed.Count;
            return parsed.TryGetValue(key, out value);
        }

        // ------------------------------------------------------------------ 内置 JSON 解析

        /// <summary>
        /// 只认识 {"entries":[{"k":"...","v":"..."}]} 的小解析器，不引第三方 JSON 库（R2）。
        /// 对未知字段用 SkipValue 跳过，允许未来加 version/note 等字段。
        /// </summary>
        static class BuiltinJson
        {
            public static bool TryParseEntries(string json, out Dictionary<string, string> entries, out string error)
            {
                entries = new Dictionary<string, string>(StringComparer.Ordinal);
                error = null;

                try
                {
                    if (!string.IsNullOrEmpty(json) && json[0] == '\uFEFF') json = json.Substring(1);

                    var p = new Parser(json);
                    p.Expect('{');

                    var foundEntries = false;
                    while (true)
                    {
                        p.SkipWhitespace();
                        if (p.TryConsume('}')) break;

                        var name = p.ReadString();
                        p.Expect(':');

                        if (name == "entries")
                        {
                            foundEntries = true;
                            p.Expect('[');

                            while (true)
                            {
                                p.SkipWhitespace();
                                if (p.TryConsume(']')) break;

                                p.Expect('{');
                                string k = null;
                                string v = null;

                                while (true)
                                {
                                    p.SkipWhitespace();
                                    if (p.TryConsume('}')) break;

                                    var prop = p.ReadString();
                                    p.Expect(':');

                                    if (prop == "k") k = p.ReadString();
                                    else if (prop == "v") v = p.ReadString();
                                    else p.SkipValue();

                                    p.SkipWhitespace();
                                    if (p.TryConsume(',')) continue;

                                    p.Expect('}');
                                    break;
                                }

                                if (!string.IsNullOrEmpty(k) && !string.IsNullOrEmpty(v)) entries[k] = v;

                                p.SkipWhitespace();
                                if (p.TryConsume(',')) continue;

                                p.Expect(']');
                                break;
                            }
                        }
                        else
                        {
                            p.SkipValue();
                        }

                        p.SkipWhitespace();
                        if (p.TryConsume(',')) continue;

                        p.Expect('}');
                        break;
                    }

                    if (!foundEntries)
                    {
                        error = "missing \"entries\" array";
                        return false;
                    }

                    if (p.Warnings.Count > 0)
                    {
                        foreach (var warning in p.Warnings)
                            Debug.LogWarning("[YGTextTranslator] builtin.json 解析警告：" + warning);
                    }

                    return true;
                }
                catch (Exception ex)
                {
                    error = "JSON: " + ex.Message;
                    return false;
                }
            }

            sealed class Parser
            {
                readonly string _s;
                int _i;
                public readonly List<string> Warnings = new List<string>();

                public Parser(string s)
                {
                    _s = s ?? string.Empty;
                }

                public void SkipWhitespace()
                {
                    while (_i < _s.Length && char.IsWhiteSpace(_s[_i])) _i++;
                }

                public bool TryConsume(char c)
                {
                    SkipWhitespace();
                    if (_i < _s.Length && _s[_i] == c)
                    {
                        _i++;
                        return true;
                    }

                    return false;
                }

                public void Expect(char c)
                {
                    SkipWhitespace();
                    if (_i >= _s.Length || _s[_i] != c)
                        throw new FormatException($"expected '{c}' at {_i}");
                    _i++;
                }

                public string ReadString()
                {
                    SkipWhitespace();
                    if (_i >= _s.Length || _s[_i] != '"')
                        throw new FormatException($"expected '\"' at {_i}");

                    _i++;
                    var sb = new StringBuilder();

                    while (_i < _s.Length)
                    {
                        var c = _s[_i++];
                        if (c == '"') return sb.ToString();
                        if (c != '\\')
                        {
                            sb.Append(c);
                            continue;
                        }

                        if (_i >= _s.Length) throw new FormatException("unterminated escape");
                        var e = _s[_i++];
                        switch (e)
                        {
                            case '"': sb.Append('"'); break;
                            case '\\': sb.Append('\\'); break;
                            case '/': sb.Append('/'); break;
                            case 'b': sb.Append('\b'); break;
                            case 'f': sb.Append('\f'); break;
                            case 'n': sb.Append('\n'); break;
                            case 'r': sb.Append('\r'); break;
                            case 't': sb.Append('\t'); break;
                            case 'u':
                            {
                                var start = _i;
                                var valid = _i + 4 <= _s.Length;
                                var code = 0;
                                if (valid)
                                {
                                    for (var k = 0; k < 4; k++)
                                    {
                                        var digit = HexValue(_s[_i + k]);
                                        if (digit < 0) { valid = false; break; }
                                        code = (code << 4) | digit;
                                    }
                                }

                                if (!valid)
                                {
                                    // 坏词条（如 \u12）只记一条 warning，按字面保留，不打断整本词典。
                                    Warnings.Add($"非法 \\u 转义 at {start - 2}，按字面保留");
                                    sb.Append('\\').Append('u');
                                }
                                else
                                {
                                    sb.Append((char)code);
                                    _i += 4;
                                }
                                break;
                            }
                            default:
                                Warnings.Add($"非法转义 '\\{e}' at {_i - 2}，按字面保留");
                                sb.Append('\\').Append(e);
                                break;
                        }
                    }

                    throw new FormatException("unterminated string");
                }

                static int HexValue(char c)
                {
                    if (c >= '0' && c <= '9') return c - '0';
                    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
                    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
                    return -1;
                }

                public void SkipValue()
                {
                    SkipWhitespace();
                    if (_i >= _s.Length) throw new FormatException("unexpected end");

                    var c = _s[_i];
                    if (c == '"')
                    {
                        ReadString();
                        return;
                    }

                    if (c == '{')
                    {
                        _i++;
                        while (true)
                        {
                            SkipWhitespace();
                            if (TryConsume('}')) return;
                            ReadString();
                            Expect(':');
                            SkipValue();
                            SkipWhitespace();
                            if (TryConsume(',')) continue;
                            Expect('}');
                            return;
                        }
                    }

                    if (c == '[')
                    {
                        _i++;
                        while (true)
                        {
                            SkipWhitespace();
                            if (TryConsume(']')) return;
                            SkipValue();
                            SkipWhitespace();
                            if (TryConsume(',')) continue;
                            Expect(']');
                            return;
                        }
                    }

                    while (_i < _s.Length)
                    {
                        var d = _s[_i];
                        if (d == ',' || d == '}' || d == ']' || char.IsWhiteSpace(d)) return;
                        _i++;
                    }
                }
            }
        }
    }
}
